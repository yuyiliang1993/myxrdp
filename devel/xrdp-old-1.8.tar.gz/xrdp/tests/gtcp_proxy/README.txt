
gtcp-proxy is a 'man in the middle' program to monitor data flowing between
two network connections.


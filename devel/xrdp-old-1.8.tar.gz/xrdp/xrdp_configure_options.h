#define XRDP_CONFIGURE_OPTIONS \
"      --enable-neutrinordp\n" \
"      --enable-ipv6\n" \
"      --disable-rfxcodec\n" \
""

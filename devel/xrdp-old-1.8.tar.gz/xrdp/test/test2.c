#include <stdio.h>
#include <ctype.h>
#include <string.h>

#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <ctype.h>
#include <stdbool.h>
#include <signal.h>

#define if_free(p) if((p!=NULL)){free(p);}

static char *trimStringSpace(char *str){
	if(str == NULL || strlen(str) == 0)
		return str;
	char *left = str;
	char *right = str+strlen(str)-1;
	while(left < right && isspace((int)*left))
		++left;
	while(right > left && isspace((int)*right))
		*right-- = 0x00;
	return left;
}


char *getLineFromFile(const char*filename,int lineNum,char *line,int size){
	if(line==NULL ||size<=0||\
		filename == NULL ||lineNum <=0){
		errno = EINVAL;
		return NULL;
	}
	int count = 0;	
	char *result = NULL;
	FILE *fp = fopen(filename,"r");
	if(fp == NULL){
		return NULL;
	}
	while(1){
		memset(line,0,size);
		if(fgets(line,size,fp) == NULL){
			if(feof(fp) || ferror(fp)){
				break;
			}
			continue;
		}
		if(++count == lineNum){
			result = trimStringSpace(line);
			break;
		}
	}
	
	fclose(fp);
	return result;	
}


int extra_getDirectMenuTempSidFromFile(char *dstBuf,int size,const char *filename)
{
	if(dstBuf==NULL||size<= 0||filename==NULL){
		errno = EINVAL;
		return (-1);
	}
	char buffer[1024]={0};
	char *line = getLineFromFile(filename,3,buffer,sizeof(buffer));
	if(line && strlen(line)<size){
		strcpy(dstBuf,line);
		trimStringSpace(dstBuf);
		return 0;
	}
	return (-1);
}

#define FILE_NAME "./test.dat"

void test(){
	char buffer[256]={0};
	char line[256];
	int count = 0;

	if(extra_getDirectMenuTempSidFromFile(buffer,256,FILE_NAME)==0){
		printf("success\n");
	}
	printf("%s\n",buffer);

}

void test2(){
	char buffer[256]={0};
	char line[256];
	int count = 0;


	while(count++ <5){
		printf("please input line:\n");
		scanf("%s",buffer);
		printf("line:%s\n",getLineFromFile(FILE_NAME,atoi(buffer),line,sizeof(line)));
	}

}

int main(int argc,char*argv[])
{
	test();
}

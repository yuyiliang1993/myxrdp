#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<errno.h>

static char *extra_trimSpace(const char *str){
	if(str == NULL)
		return NULL;
	if(strlen(str) == 0)
		return NULL;
	const char *start = str;
	const char *end = str+strlen(str)-1;
	while(start < end && isspace((int)*start))
		++start;
	while(end > start && isspace((int)*end))
		--end;
	if(start >= end)
		return NULL;
	
	int len = end-start+1;
	char * mem = (char*)malloc(sizeof(char)*len+1);
	if(mem == NULL)
		return NULL;
	memcpy(mem,start,len);
	mem[len]=0x00;
	return mem;
}

char *getLineStringFromFile(const char*filename,int lineNum){
	if(filename == NULL ||lineNum <=0)
		return NULL;
	char buffer[1024];
	int count = 0;	
	char *result = NULL;
	FILE *fp = fopen(filename,"r");
	if(fp == NULL){
		perror("fopen");
		return NULL;
	}
	while(1){
		memset(buffer,0,sizeof(buffer));
		if(fgets(buffer,sizeof(buffer),fp) == NULL){
			if(feof(fp)){
				break;
			}
			else if(ferror(fp)){
				perror("fgets");
				break;
			}
			continue;
		}
		if(buffer[0]==0x00 || buffer[0] == '#')
			continue;
		if(++count == lineNum){
			result = extra_trimSpace(buffer);
			break;
		}
	}
	fclose(fp);
	return result;	
}


int main(){
	printf("size:%d\n",sizeof(pid_t));
	char buffer[1024];
	while(1){
		printf("input linenum:\n");
		scanf("%s",buffer);
		char *data = getLineStringFromFile("./test.dat",atoi(buffer));
		printf("data:%s\n",data);
		if(data)
			free(data);
	}
}

#!/usr/bin/sh
echo "123456-$1>>/tmp/.sessionx11.tmp"
echo "123456-$1">>/tmp/.sessionx11.tmp
while true
do
	echo "testx11.sh:$(date)"
	sleep 1
done

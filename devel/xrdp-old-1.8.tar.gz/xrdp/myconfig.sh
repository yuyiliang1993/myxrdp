./configure --enable-neutrinordp --enable-ipv6 --disable-rfxcodec

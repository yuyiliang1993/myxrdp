/**
 * xrdp: A Remote Desktop Protocol server.
 *
 * Copyright (C) Jay Sorg 2004-2014
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * simple window manager
 */

#if defined(HAVE_CONFIG_H)
#include <config_ac.h>
#endif

#include <stdarg.h>
#include <stdio.h>
#include "xrdp.h"
#include "log.h"


#include <sys/select.h>
#include <sys/time.h>
#include <sys/types.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <inttypes.h>
#include <sys/stat.h>


#include <errno.h>
#include <sys/types.h>
#include <errno.h>
#include <stdbool.h>

#define  MAX_BUFFER_LEN 4096


#define LLOG_LEVEL 1
#define LLOGLN(_level, _args) \
	do \
{ \
	if (_level < LLOG_LEVEL) \
	{ \
		g_write("xrdp:xrdp_wm [%10.10u]: ", g_time3()); \
		g_writeln _args ; \
	} \
} \
while (0)


/*****************************************************************************/
connInfo_t *connect_info_create()
{
	connInfo_t *p=(connInfo_t*)calloc(1,sizeof(connInfo_t));
	if(p == NULL){
		perror("calloc");
		exit(1);
	}

	p->upside_clip_flag = 0;
	p->downside_clip_flag = 0;
	p->file_upside_clip_flag = 0;
	p->file_downside_clip_flag = 0;
	return p;
}

/*****************************************************************************/
struct xrdp_wm *
xrdp_wm_create(struct xrdp_process *owner,struct xrdp_client_info *client_info)
{
	struct xrdp_wm *self = (struct xrdp_wm *)NULL;
	char event_name[256];
	int pid = 0;

	/* initialize (zero out) local variables: */
	g_memset(event_name, 0, sizeof(char) * 256);

	self = (struct xrdp_wm *)g_malloc(sizeof(struct xrdp_wm), 1);
	self->client_info = client_info;
	self->screen = xrdp_bitmap_create(client_info->width,
			client_info->height,
			client_info->bpp,
			WND_TYPE_SCREEN, self);
	self->screen->wm = self;
	self->pro_layer = owner;
	self->session = owner->session;
	pid = g_getpid();
	g_snprintf(event_name, 255, "xrdp_%8.8x_wm_login_mode_event_%8.8x",
			pid, owner->session_id);
	log_message(LOG_LEVEL_DEBUG, "%s", event_name);
	self->login_mode_event = g_create_wait_obj(event_name);
	self->painter = xrdp_painter_create(self, self->session);
	self->cache = xrdp_cache_create(self, self->session, self->client_info);
	self->log = list_create();
	self->log->auto_free = 1;
	self->mm = xrdp_mm_create(self);
	self->default_font = xrdp_font_create(self);
	/* this will use built in keymap or load from file */
	get_keymaps(self->session->client_info->keylayout, &(self->keymap));
	xrdp_wm_set_login_mode(self, 0);
	self->target_surface = self->screen;
	self->current_surface_index = 0xffff; /* screen */

	/* to store configuration from xrdp.ini */
	self->xrdp_config = g_new0(struct xrdp_config, 1);

	//add by yuliang,extra code
	self->myType = CLIENT_OTHER;
	self->connect_info = connect_info_create();
	self->pid_x11_1 = 0L;
	self->pid_x11_2 = 0L;
	self->pid_dm = 0L;
	
	self->direct_menu_mode = 0;
	//add by yuliang,2019/12/26
	self->config_extra = extra_cfg_create();
	memset(self->ssid,0,sizeof(self->ssid));
	return self;
}

void monitor_set_diconnect(int type,const char *sid)
{
	int i = 0;
	client_tls_t *p;
	mutex_lock(monitor_mutex);
	for(;i<MAX_NUMS_CLIENT_TLS;++i){
		p = &client_tls_array[i];
		if(p->type == type && strcmp(p->sid,sid) == 0){
			xrdp_wm_set_login_mode(p->tls->wm, 20);
		}
	}
	mutex_unlock(monitor_mutex);
}

int pull_redis_disconnect(const char *sid)
{
	if(sid == NULL){
		return -1;	
	}
	
	int sock = socket(AF_INET,SOCK_DGRAM,0);
	if(sock < 0){
		log_message(LOG_LEVEL_ERROR,"socket:%s",strerror(errno));
		return -1;
	}
	struct sockaddr_in serv_addr;
	socklen_t addrlen = sizeof(serv_addr);
	bzero(&serv_addr,addrlen);
	serv_addr.sin_family= AF_INET;
	serv_addr.sin_port = htons(REDIS_CONN_SERVER_PORT);
	serv_addr.sin_addr.s_addr = inet_addr(REDIS_CONN_SERVER_IP);
	
	char buffer[512];
	int len = snprintf(buffer,512,"$DKLJ,%s\r\n",sid);
	log_message(LOG_LEVEL_DEBUG,"pull_redis_disconnect send:%s",buffer);
	if((sendto(sock,buffer,len,0,(struct sockaddr*)&serv_addr,addrlen)) < 0 ){
		log_message(LOG_LEVEL_ERROR,"sendto:%s",strerror(errno));
		close(sock);
		return -1;
	}	
	return 0;
}

void xrdp_about_monitor_delete(struct xrdp_wm *self)
{
	log_message(LOG_LEVEL_DEBUG,"xrdp_about_monitor_delete:");

	if (self == 0){
		return;
	}
	if(self->myType == CLIENT_OTHER){
		log_message(LOG_LEVEL_DEBUG,"self->myType == CLIENT_OTHER:");
		return ;
	}

	if(self->pro_layer != 0){
		if(self->pro_layer->server_trans != 0){
			if(self->pro_layer->server_trans->tls != 0){
				struct ssl_tls *tls = self->pro_layer->server_trans->tls;
				if(tls == NULL){
					log_message(LOG_LEVEL_ERROR,"xrdp_about_monitor_delete:tls == NULL");
					return ;
				}
				log_message(LOG_LEVEL_DEBUG,"restore:%s",tls->sid);
				if(tls->type == CLIENT_MONITOR){
					log_message(LOG_LEVEL_DEBUG,"monitor session closed");
					monitor_set_diconnect(CLIENT_MAIN,tls->sid);
					if(pull_redis_disconnect(tls->sid) != 0){
						log_message(LOG_LEVEL_WARNING,"pull_redis_disconnect failed");
					}
				}
				if(tls->type == CLIENT_MAIN){
					log_message(LOG_LEVEL_DEBUG,"main session closed");
					monitor_set_diconnect(CLIENT_MONITOR,tls->sid);
				}
				monitor_client_tls_restore(tls);
			}
		}
	}

}

/*****************************************************************************/
void xrdp_wm_delete(struct xrdp_wm *self)
{
	if (self == 0)
	{
		return;
	}
	log_message(LOG_LEVEL_DEBUG,"xrdp_wm_delete:");
	xrdp_about_monitor_delete(self);


	
	xrdp_mm_delete(self->mm);
	xrdp_cache_delete(self->cache);
	xrdp_painter_delete(self->painter);
	xrdp_bitmap_delete(self->screen);
	/* free the log */
	list_delete(self->log);
	/* free default font */
	xrdp_font_delete(self->default_font);
	g_delete_wait_obj(self->login_mode_event);

	if (self->xrdp_config)
		g_free(self->xrdp_config);

	//add by yuliang
	if(self->connect_info){
		g_free(self->connect_info);
		self->connect_info = NULL;
	}
	
	//add by yuliang ,2019/12/26
	extra_cfg_delete(self->config_extra);

	//杀死x11启动的那个程序

	if(self->pid_dm >0){
		extra_process_stop(self->pid_dm);
	}

	if(self->pid_x11_1 > 0)
		extra_process_stop(self->pid_x11_1);
	
	
	if(self->pid_x11_2 > 0)
		extra_process_stop(self->pid_x11_2);
	
//	if(strlen(self->ssid) > 0)
//		extra_process_stop_by_ssid(self->ssid);
	/* free self */
	g_free(self);
}


/*****************************************************************************/
	int
xrdp_wm_send_palette(struct xrdp_wm *self)
{
	return libxrdp_send_palette(self->session, self->palette);
}

/*****************************************************************************/
	int
xrdp_wm_send_bell(struct xrdp_wm *self)
{
	return libxrdp_send_bell(self->session);
}


/*****************************************************************************/
	int
xrdp_wm_send_bitmap(struct xrdp_wm *self, struct xrdp_bitmap *bitmap,
		int x, int y, int cx, int cy)
{
	return libxrdp_send_bitmap(self->session, bitmap->width, bitmap->height,
			bitmap->bpp, bitmap->data, x, y, cx, cy);
}

/*****************************************************************************/
	int
xrdp_wm_set_focused(struct xrdp_wm *self, struct xrdp_bitmap *wnd)
{
	struct xrdp_bitmap *focus_out_control;
	struct xrdp_bitmap *focus_in_control;

	if (self == 0)
	{
		return 0;
	}

	if (self->focused_window == wnd)
	{
		return 0;
	}

	focus_out_control = 0;
	focus_in_control = 0;

	if (self->focused_window != 0)
	{
		xrdp_bitmap_set_focus(self->focused_window, 0);
		focus_out_control = self->focused_window->focused_control;
	}

	self->focused_window = wnd;

	if (self->focused_window != 0)
	{
		xrdp_bitmap_set_focus(self->focused_window, 1);
		focus_in_control = self->focused_window->focused_control;
	}

	xrdp_bitmap_invalidate(focus_out_control, 0);
	xrdp_bitmap_invalidate(focus_in_control, 0);
	return 0;
}


/******************************************************************************/
	static int
xrdp_wm_get_pixel(char *data, int x, int y, int width, int bpp)
{
	int start;
	int shift;

	if (bpp == 1)
	{
		width = (width + 7) / 8;
		start = (y * width) + x / 8;
		shift = x % 8;
		return (data[start] & (0x80 >> shift)) != 0;
	}
	else if (bpp == 4)
	{
		width = (width + 1) / 2;
		start = y * width + x / 2;
		shift = x % 2;

		if (shift == 0)
		{
			return (data[start] & 0xf0) >> 4;
		}
		else
		{
			return data[start] & 0x0f;
		}
	}

	return 0;
}


/*****************************************************************************/
	int
xrdp_wm_pointer(struct xrdp_wm *self, char *data, char *mask, int x, int y,
		int bpp)
{
	int bytes;
	struct xrdp_pointer_item pointer_item;

	if (bpp == 0)
	{
		bpp = 24;
	}
	bytes = ((bpp + 7) / 8) * 32 * 32;
	g_memset(&pointer_item, 0, sizeof(struct xrdp_pointer_item));
	pointer_item.x = x;
	pointer_item.y = y;
	pointer_item.bpp = bpp;
	g_memcpy(pointer_item.data, data, bytes);
	g_memcpy(pointer_item.mask, mask, 32 * 32 / 8);
	self->screen->pointer = xrdp_cache_add_pointer(self->cache, &pointer_item);
	return 0;
}

/*****************************************************************************/
/* returns error */
	int
xrdp_wm_load_pointer(struct xrdp_wm *self, char *file_name, char *data,
		char *mask, int *x, int *y)
{
	int fd;
	int bpp;
	int w;
	int h;
	int i;
	int j;
	int pixel;
	int palette[16];
	struct stream *fs;

	if (!g_file_exist(file_name))
	{
		log_message(LOG_LEVEL_ERROR,"xrdp_wm_load_pointer: error pointer file [%s] does not exist",
				file_name);
		return 1;
	}

	make_stream(fs);
	init_stream(fs, 8192);
	fd = g_file_open(file_name);

	if (fd < 0)
	{
		log_message(LOG_LEVEL_ERROR,"xrdp_wm_load_pointer: error loading pointer from file [%s]",
				file_name);
		xstream_free(fs);
		return 1;
	}

	g_file_read(fd, fs->data, 8192);
	g_file_close(fd);
	in_uint8s(fs, 6);
	in_uint8(fs, w);
	in_uint8(fs, h);
	in_uint8s(fs, 2);
	in_uint16_le(fs, *x);
	in_uint16_le(fs, *y);
	in_uint8s(fs, 22);
	in_uint8(fs, bpp);
	in_uint8s(fs, 25);

	if (w == 32 && h == 32)
	{
		if (bpp == 1)
		{
			for (i = 0; i < 2; i++)
			{
				in_uint32_le(fs, pixel);
				palette[i] = pixel;
			}
			for (i = 0; i < 32; i++)
			{
				for (j = 0; j < 32; j++)
				{
					pixel = palette[xrdp_wm_get_pixel(fs->p, j, i, 32, 1)];
					*data = pixel;
					data++;
					*data = pixel >> 8;
					data++;
					*data = pixel >> 16;
					data++;
				}
			}

			in_uint8s(fs, 128);
		}
		else if (bpp == 4)
		{
			for (i = 0; i < 16; i++)
			{
				in_uint32_le(fs, pixel);
				palette[i] = pixel;
			}
			for (i = 0; i < 32; i++)
			{
				for (j = 0; j < 32; j++)
				{
					pixel = palette[xrdp_wm_get_pixel(fs->p, j, i, 32, 1)];
					*data = pixel;
					data++;
					*data = pixel >> 8;
					data++;
					*data = pixel >> 16;
					data++;
				}
			}

			in_uint8s(fs, 512);
		}

		g_memcpy(mask, fs->p, 128); /* mask */
	}

	free_stream(fs);
	return 0;
}

/*****************************************************************************/
	int
xrdp_wm_send_pointer(struct xrdp_wm *self, int cache_idx,
		char *data, char *mask, int x, int y, int bpp)
{
	return libxrdp_send_pointer(self->session, cache_idx, data, mask,
			x, y, bpp);
}

/*****************************************************************************/
	int
xrdp_wm_set_pointer(struct xrdp_wm *self, int cache_idx)
{
	return libxrdp_set_pointer(self->session, cache_idx);
}

/*****************************************************************************/
/* convert hex string to int */
	unsigned int
xrdp_wm_htoi (const char *ptr)
{
	unsigned int value = 0;
	char ch = *ptr;

	while (ch == ' ' || ch == '\t')
	{
		ch = *(++ptr);
	}

	for (;;)
	{
		if (ch >= '0' && ch <= '9')
		{
			value = (value << 4) + (ch - '0');
		}
		else if (ch >= 'A' && ch <= 'F')
		{
			value = (value << 4) + (ch - 'A' + 10);
		}
		else if (ch >= 'a' && ch <= 'f')
		{
			value = (value << 4) + (ch - 'a' + 10);
		}
		else
		{
			return value;
		}

		ch = *(++ptr);
	}
}


/*****************************************************************************/
int
xrdp_wm_load_static_colors_plus(struct xrdp_wm *self, char *autorun_name)
{
	int bindex;
	int gindex;
	int rindex;

	int fd;
	int index;
	char *val;
	struct list *names;
	struct list *values;
	char cfg_file[256];

	if (autorun_name != 0)
	{
		autorun_name[0] = 0;
	}

	/* initialize with defaults */
	self->black      = HCOLOR(self->screen->bpp, 0x000000);
	self->grey       = HCOLOR(self->screen->bpp, 0xc0c0c0);
	self->dark_grey  = HCOLOR(self->screen->bpp, 0x808080);
	self->blue       = HCOLOR(self->screen->bpp, 0x0000ff);
	self->dark_blue  = HCOLOR(self->screen->bpp, 0x00007f);
	self->white      = HCOLOR(self->screen->bpp, 0xffffff);
	self->red        = HCOLOR(self->screen->bpp, 0xff0000);
	self->green      = HCOLOR(self->screen->bpp, 0x00ff00);
	self->background = HCOLOR(self->screen->bpp, 0x000000);

	/* now load them from the globals in xrdp.ini if defined */
	g_snprintf(cfg_file, 255, "%s/xrdp.ini", XRDP_CFG_PATH);
	fd = g_file_open(cfg_file);

	if (fd >= 0)
	{
		names = list_create();
		names->auto_free = 1;
		values = list_create();
		values->auto_free = 1;

		if (file_read_section(fd, "globals", names, values) == 0)
		{
			for (index = 0; index < names->count; index++)
			{
				val = (char *)list_get_item(names, index);

				if (val != 0)
				{
					if (g_strcasecmp(val, "black") == 0)
					{
						val = (char *)list_get_item(values, index);
						self->black = HCOLOR(self->screen->bpp,xrdp_wm_htoi(val));
					}
					else if (g_strcasecmp(val, "grey") == 0)
					{
						val = (char *)list_get_item(values, index);
						self->grey = HCOLOR(self->screen->bpp, xrdp_wm_htoi(val));
					}
					else if (g_strcasecmp(val, "dark_grey") == 0)
					{
						val = (char *)list_get_item(values, index);
						self->dark_grey = HCOLOR(self->screen->bpp, xrdp_wm_htoi(val));
					}
					else if (g_strcasecmp(val, "blue") == 0)
					{
						val = (char *)list_get_item(values, index);
						self->blue = HCOLOR(self->screen->bpp, xrdp_wm_htoi(val));
					}
					else if (g_strcasecmp(val, "dark_blue") == 0)
					{
						val = (char *)list_get_item(values, index);
						self->dark_blue = HCOLOR(self->screen->bpp, xrdp_wm_htoi(val));
					}
					else if (g_strcasecmp(val, "white") == 0)
					{
						val = (char *)list_get_item(values, index);
						self->white = HCOLOR(self->screen->bpp, xrdp_wm_htoi(val));
					}
					else if (g_strcasecmp(val, "red") == 0)
					{
						val = (char *)list_get_item(values, index);
						self->red = HCOLOR(self->screen->bpp, xrdp_wm_htoi(val));
					}
					else if (g_strcasecmp(val, "green") == 0)
					{
						val = (char *)list_get_item(values, index);
						self->green = HCOLOR(self->screen->bpp, xrdp_wm_htoi(val));
					}
					else if (g_strcasecmp(val, "background") == 0)
					{
						val = (char *)list_get_item(values, index);
						self->background = HCOLOR(self->screen->bpp, xrdp_wm_htoi(val));
					}
					else if (g_strcasecmp(val, "autorun") == 0)
					{
						val = (char *)list_get_item(values, index);

						if (autorun_name != 0)
						{
							g_strncpy(autorun_name, val, 255);
						}
					}
					else if (g_strcasecmp(val, "hidelogwindow") == 0)
					{
						val = (char *)list_get_item(values, index);
						self->hide_log_window = g_text2bool(val);
					}
					else if (g_strcasecmp(val, "pamerrortxt") == 0)
					{
						val = (char *)list_get_item(values, index);
						g_strncpy(self->pamerrortxt, val, 255);
					}
				}
			}
		}

		list_delete(names);
		list_delete(values);
		g_file_close(fd);
	}
	else
	{
		log_message(LOG_LEVEL_ERROR,"xrdp_wm_load_static_colors: Could not read xrdp.ini file %s", cfg_file);
	}

	if (self->screen->bpp == 8)
	{
		/* rgb332 */
		for (bindex = 0; bindex < 4; bindex++)
		{
			for (gindex = 0; gindex < 8; gindex++)
			{
				for (rindex = 0; rindex < 8; rindex++)
				{
					self->palette[(bindex << 6) | (gindex << 3) | rindex] =
						(((rindex << 5) | (rindex << 2) | (rindex >> 1)) << 16) |
						(((gindex << 5) | (gindex << 2) | (gindex >> 1)) << 8) |
						((bindex << 6) | (bindex << 4) | (bindex << 2) | (bindex));
				}
			}
		}

		xrdp_wm_send_palette(self);
	}

	return 0;
}


/*****************************************************************************/
/* returns error */
	int
xrdp_wm_load_static_pointers(struct xrdp_wm *self)
{
	struct xrdp_pointer_item pointer_item;
	char file_path[256];

	DEBUG(("sending cursor"));
	g_snprintf(file_path, 255, "%s/cursor1.cur", XRDP_SHARE_PATH);
	g_memset(&pointer_item, 0, sizeof(pointer_item));
	xrdp_wm_load_pointer(self, file_path, pointer_item.data,
			pointer_item.mask, &pointer_item.x, &pointer_item.y);
	xrdp_cache_add_pointer_static(self->cache, &pointer_item, 1);
	DEBUG(("sending cursor"));
	g_snprintf(file_path, 255, "%s/cursor0.cur", XRDP_SHARE_PATH);
	g_memset(&pointer_item, 0, sizeof(pointer_item));
	xrdp_wm_load_pointer(self, file_path, pointer_item.data,
			pointer_item.mask, &pointer_item.x, &pointer_item.y);
	xrdp_cache_add_pointer_static(self->cache, &pointer_item, 0);
	return 0;
}

/*****************************************************************************/
int
xrdp_wm_init(struct xrdp_wm *self)
{
	int fd;
	int index;
	struct list *names;
	struct list *values;
	char *q;
	const char *r;
	char param[256];
	char default_section_name[256];
	char section_name[256];
	char cfg_file[256];
	char autorun_name[256];

	g_writeln("in xrdp_wm_init: ");

	load_xrdp_config(self->xrdp_config, self->screen->bpp);

	/* global channels allow */
	names = list_create();
	names->auto_free = 1;
	values = list_create();
	values->auto_free = 1;
	g_snprintf(cfg_file, 255, "%s/xrdp.ini", XRDP_CFG_PATH);
	if (file_by_name_read_section(cfg_file, "Channels", names, values) == 0)
	{
		int error;
		int ii;
		int chan_id;
		int chan_flags;
		int disabled;
		char chan_name[16];

		ii = 0;
		error = libxrdp_query_channel(self->session, ii, chan_name,
				&chan_flags);
		while (error == 0)
		{
			r = NULL;
			for (index = 0; index < names->count; index++)
			{
				q = (char *) list_get_item(names, index);
				if (g_strcasecmp(q, chan_name) == 0)
				{
					r = (char *) list_get_item(values, index);
					break;
				}
			}
			if (r == NULL)
			{
				/* not found, disable the channel */
				chan_id = libxrdp_get_channel_id(self->session, chan_name);
				libxrdp_disable_channel(self->session, chan_id, 1);
				g_writeln("xrdp_wm_init: channel %s channel id %d is "
						"disabled", chan_name, chan_id);
			}
			else
			{
				/* found */
				chan_id = libxrdp_get_channel_id(self->session, q);
				disabled = !g_text2bool(r);
				libxrdp_disable_channel(self->session, chan_id, disabled);
				if (disabled)
				{
					g_writeln("xrdp_wm_init: channel %s channel id %d is "
							"disabled", chan_name, chan_id);
				}
				else
				{
					g_writeln("xrdp_wm_init: channel %s channel id %d is "
							"allowed", chan_name, chan_id);
				}
			}
			ii++;
			error = libxrdp_query_channel(self->session, ii, chan_name,
					&chan_flags);
		}
	}
	list_delete(names);
	list_delete(values);

	xrdp_wm_load_static_colors_plus(self, autorun_name);
	xrdp_wm_load_static_pointers(self);
	self->screen->bg_color = self->xrdp_config->cfg_globals.ls_top_window_bg_color;

	//add by yuliang ,2019/12/26
	if(!extra_read_config(self->config_extra,XRDP_EXTRA_CONF_NAME)){
		log_message(LOG_LEVEL_ERROR, "xrdp_extra_read_config failed");	
		
	}
	
	self->session->client_info->rdp_autologin = 2;
	if(self->session->client_info->rdp_autologin == 2){
		if(strncasecmp(self->config_extra->directMenuFlag,"true",4)==0)
			xrdp_wm_set_login_mode(self, 21);//进入直连菜单逻辑
		else
			xrdp_wm_set_login_mode(self, 2);//旧版逻辑
	}
	//end add 
	else if (self->session->client_info->rdp_autologin == 1)
	{
		/*
		 * NOTE: this should eventually be accessed from self->xrdp_config
		 */

		g_snprintf(cfg_file, 255, "%s/xrdp.ini", XRDP_CFG_PATH);
		fd = g_file_open(cfg_file); /* xrdp.ini */
		if (fd != -1)
		{
			names = list_create();
			names->auto_free = 1;
			values = list_create();
			values->auto_free = 1;

			/* pick up the first section name except for 'globals', 'Logging', 'channels'
			 * in xrdp.ini and use it as default section name */
			file_read_sections(fd, names);
			default_section_name[0] = '\0';
			for (index = 0; index < names->count; index++)
			{
				q = (char *)list_get_item(names, index);
				if ((g_strncasecmp("globals", q, 8) != 0) &&
						(g_strncasecmp("Logging", q, 8) != 0) &&
						(g_strncasecmp("channels", q, 9) != 0))
				{
					g_strncpy(default_section_name, q, 255);
					break;
				}
			}

			/* look for module name to be loaded */
			if (autorun_name[0] != 0)
			{
				/* if autorun is configured in xrdp.ini, we enforce that module to be loaded */
				g_strncpy(section_name, autorun_name, 255);
			}
			else if (self->session->client_info->domain[0] != '\0' &&
					self->session->client_info->domain[0] != '_')
			{
				/* domain names that starts with '_' are reserved for IP/DNS to
				 * simplify for the user in a proxy setup */

				/* we use the domain name as the module name to be loaded */
				g_strncpy(section_name,
						self->session->client_info->domain, 255);
			}
			else
			{
				/* if no domain is given, and autorun is not specified in xrdp.ini
				 * use default_section_name as section_name  */
				g_strncpy(section_name, default_section_name, 255);
			}

			list_clear(names);

			/* if given section name doesn't match any sections configured
			 * in xrdp.ini, fallback to default_section_name */
			if (file_read_section(fd, section_name, names, values) != 0)
			{
				log_message(LOG_LEVEL_INFO,
						"Module \"%s\" specified by %s from %s port %s "
						"is not configured. Using \"%s\" instead.",
						section_name,
						self->session->client_info->username,
						self->session->client_info->client_addr,
						self->session->client_info->client_port,
						default_section_name);
				list_clear(names);
				list_clear(values);

				g_strncpy(section_name, default_section_name, 255);
			}

			/* look for the required module in xrdp.ini, fetch its parameters */
			if (file_read_section(fd, section_name, names, values) == 0)
			{
				for (index = 0; index < names->count; index++)
				{
					q = (char *)list_get_item(names, index);
					r = (char *)list_get_item(values, index);

					if (g_strncmp("password", q, 255) == 0)
					{
						/* if the password has been asked for by the module, use what the
						   client says.
						   if the password has been manually set in the config, use that
						   instead of what the client says. */
						if (g_strncmp("ask", r, 3) == 0)
						{
							r = self->session->client_info->password;
						}
					}
					else if (g_strncmp("username", q, 255) == 0)
					{
						/* if the username has been asked for by the module, use what the
						   client says.
						   if the username has been manually set in the config, use that
						   instead of what the client says. */
						if (g_strncmp("ask", r, 3) == 0)
						{
							r = self->session->client_info->username;
						}
					}
					else if (g_strncmp("ip", q, 255) == 0)
					{
						/* if the ip has been asked for by the module, use what the
						   client says (target ip should be in 'domain' field, when starting with "_")
						   if the ip has been manually set in the config, use that
						   instead of what the client says. */
						if (g_strncmp("ask", r, 3) == 0)
						{
							if (self->session->client_info->domain[0] == '_')
							{
								g_strncpy(param, &self->session->client_info->domain[1], 255);
								r = param;
							}

						}
					}
					else if (g_strncmp("port", q, 255) == 0)
					{
						if (g_strncmp("ask3389", r, 7) == 0)
						{
							r = "3389"; /* use default */
						}
					}

					list_add_item(self->mm->login_names, (long)g_strdup(q));
					list_add_item(self->mm->login_values, (long)g_strdup(r));
				}

				xrdp_wm_set_login_mode(self, 2);
			}
			else
			{
				/* Hopefully, we never reach here. */
				log_message(LOG_LEVEL_DEBUG,
						"Control should never reach %s:%d", __FILE__, __LINE__);
			}

			list_delete(names);
			list_delete(values);
			g_file_close(fd);
		}
		else
		{
			log_message(LOG_LEVEL_ERROR,"xrdp_wm_init: Could not read xrdp.ini file %s", cfg_file);
		}
	}
	else
	{
		g_writeln("   xrdp_wm_init: no autologin / auto run detected, draw login window");
		xrdp_login_wnd_create(self);
		/* clear screen */
		xrdp_bitmap_invalidate(self->screen, 0);
		xrdp_wm_set_focused(self, self->login_window);
		xrdp_wm_set_login_mode(self, 1);
	}

	g_writeln("out xrdp_wm_init: ");
	return 0;
}

/*****************************************************************************/
/* returns the number for rects visible for an area relative to a drawable */
/* putting the rects in region */
	int
xrdp_wm_get_vis_region(struct xrdp_wm *self, struct xrdp_bitmap *bitmap,
		int x, int y, int cx, int cy,
		struct xrdp_region *region, int clip_children)
{
	int i;
	struct xrdp_bitmap *p;
	struct xrdp_rect a;
	struct xrdp_rect b;

	/* area we are drawing */
	MAKERECT(a, bitmap->left + x, bitmap->top + y, cx, cy);
	p = bitmap->parent;

	while (p != 0)
	{
		RECTOFFSET(a, p->left, p->top);
		p = p->parent;
	}

	a.left = MAX(self->screen->left, a.left);
	a.top = MAX(self->screen->top, a.top);
	a.right = MIN(self->screen->left + self->screen->width, a.right);
	a.bottom = MIN(self->screen->top + self->screen->height, a.bottom);
	xrdp_region_add_rect(region, &a);

	if (clip_children)
	{
		/* loop through all windows in z order */
		for (i = 0; i < self->screen->child_list->count; i++)
		{
			p = (struct xrdp_bitmap *)list_get_item(self->screen->child_list, i);

			if (p == bitmap || p == bitmap->parent)
			{
				return 0;
			}

			MAKERECT(b, p->left, p->top, p->width, p->height);
			xrdp_region_subtract_rect(region, &b);
		}
	}

	return 0;
}

/*****************************************************************************/
/* return the window at x, y on the screen */
	static struct xrdp_bitmap *
xrdp_wm_at_pos(struct xrdp_bitmap *wnd, int x, int y,
		struct xrdp_bitmap **wnd1)
{
	int i;
	struct xrdp_bitmap *p;
	struct xrdp_bitmap *q;

	/* loop through all windows in z order */
	for (i = 0; i < wnd->child_list->count; i++)
	{
		p = (struct xrdp_bitmap *)list_get_item(wnd->child_list, i);

		if (x >= p->left && y >= p->top && x < p->left + p->width &&
				y < p->top + p->height)
		{
			if (wnd1 != 0)
			{
				*wnd1 = p;
			}

			q = xrdp_wm_at_pos(p, x - p->left, y - p->top, 0);

			if (q == 0)
			{
				return p;
			}
			else
			{
				return q;
			}
		}
	}

	return 0;
}

/*****************************************************************************/
	static int
xrdp_wm_xor_pat(struct xrdp_wm *self, int x, int y, int cx, int cy)
{
	self->painter->clip_children = 0;
	self->painter->rop = 0x5a;
	xrdp_painter_begin_update(self->painter);
	self->painter->use_clip = 0;
	self->painter->mix_mode = 1;
	self->painter->brush.pattern[0] = 0xaa;
	self->painter->brush.pattern[1] = 0x55;
	self->painter->brush.pattern[2] = 0xaa;
	self->painter->brush.pattern[3] = 0x55;
	self->painter->brush.pattern[4] = 0xaa;
	self->painter->brush.pattern[5] = 0x55;
	self->painter->brush.pattern[6] = 0xaa;
	self->painter->brush.pattern[7] = 0x55;
	self->painter->brush.x_origin = 0;
	self->painter->brush.x_origin = 0;
	self->painter->brush.style = 3;
	self->painter->bg_color = self->black;
	self->painter->fg_color = self->white;
	/* top */
	xrdp_painter_fill_rect(self->painter, self->screen, x, y, cx, 5);
	/* bottom */
	xrdp_painter_fill_rect(self->painter, self->screen, x, y + (cy - 5), cx, 5);
	/* left */
	xrdp_painter_fill_rect(self->painter, self->screen, x, y + 5, 5, cy - 10);
	/* right */
	xrdp_painter_fill_rect(self->painter, self->screen, x + (cx - 5), y + 5, 5,
			cy - 10);
	xrdp_painter_end_update(self->painter);
	self->painter->rop = 0xcc;
	self->painter->clip_children = 1;
	self->painter->mix_mode = 0;
	return 0;
}

/*****************************************************************************/
/* return true if rect is totally exposed going in reverse z order */
/* from wnd up */
	static int
xrdp_wm_is_rect_vis(struct xrdp_wm *self, struct xrdp_bitmap *wnd,
		struct xrdp_rect *rect)
{
	struct xrdp_rect wnd_rect;
	struct xrdp_bitmap *b;
	int i;;

	/* if rect is part off screen */
	if (rect->left < 0)
	{
		return 0;
	}

	if (rect->top < 0)
	{
		return 0;
	}

	if (rect->right >= self->screen->width)
	{
		return 0;
	}

	if (rect->bottom >= self->screen->height)
	{
		return 0;
	}

	i = list_index_of(self->screen->child_list, (long)wnd);
	i--;

	while (i >= 0)
	{
		b = (struct xrdp_bitmap *)list_get_item(self->screen->child_list, i);
		MAKERECT(wnd_rect, b->left, b->top, b->width, b->height);

		if (rect_intersect(rect, &wnd_rect, 0))
		{
			return 0;
		}

		i--;
	}

	return 1;
}

/*****************************************************************************/
	static int
xrdp_wm_move_window(struct xrdp_wm *self, struct xrdp_bitmap *wnd,
		int dx, int dy)
{
	struct xrdp_rect rect1;
	struct xrdp_rect rect2;
	struct xrdp_region *r;
	int i;

	MAKERECT(rect1, wnd->left, wnd->top, wnd->width, wnd->height);

	self->painter->clip_children = 0;
	if (xrdp_wm_is_rect_vis(self, wnd, &rect1))
	{
		rect2 = rect1;
		RECTOFFSET(rect2, dx, dy);

		if (xrdp_wm_is_rect_vis(self, wnd, &rect2))
		{
			xrdp_painter_begin_update(self->painter);
			xrdp_painter_copy(self->painter, self->screen, self->screen,
					wnd->left + dx, wnd->top + dy,
					wnd->width, wnd->height,
					wnd->left, wnd->top);
			xrdp_painter_end_update(self->painter);

			wnd->left += dx;
			wnd->top += dy;
			r = xrdp_region_create(self);
			xrdp_region_add_rect(r, &rect1);
			xrdp_region_subtract_rect(r, &rect2);
			i = 0;

			while (xrdp_region_get_rect(r, i, &rect1) == 0)
			{
				xrdp_bitmap_invalidate(self->screen, &rect1);
				i++;
			}

			xrdp_region_delete(r);
			self->painter->clip_children = 1;
			return 0;
		}
	}
	self->painter->clip_children = 1;

	wnd->left += dx;
	wnd->top += dy;
	xrdp_bitmap_invalidate(self->screen, &rect1);
	xrdp_bitmap_invalidate(wnd, 0);
	return 0;
}


/*****************************************************************************/
	static int
xrdp_wm_undraw_dragging_box(struct xrdp_wm *self, int do_begin_end)
{
	int boxx;
	int boxy;

	if (self == 0)
	{
		return 0;
	}

	if (self->dragging)
	{
		if (self->draggingxorstate)
		{
			if (do_begin_end)
			{
				xrdp_painter_begin_update(self->painter);
			}

			boxx = self->draggingx - self->draggingdx;
			boxy = self->draggingy - self->draggingdy;
			xrdp_wm_xor_pat(self, boxx, boxy, self->draggingcx, self->draggingcy);
			self->draggingxorstate = 0;

			if (do_begin_end)
			{
				xrdp_painter_end_update(self->painter);
			}
		}
	}

	return 0;
}

/*****************************************************************************/
	static int
xrdp_wm_draw_dragging_box(struct xrdp_wm *self, int do_begin_end)
{
	int boxx;
	int boxy;

	if (self == 0)
	{
		return 0;
	}

	if (self->dragging)
	{
		if (!self->draggingxorstate)
		{
			if (do_begin_end)
			{
				xrdp_painter_begin_update(self->painter);
			}

			boxx = self->draggingx - self->draggingdx;
			boxy = self->draggingy - self->draggingdy;
			xrdp_wm_xor_pat(self, boxx, boxy, self->draggingcx, self->draggingcy);
			self->draggingxorstate = 1;

			if (do_begin_end)
			{
				xrdp_painter_end_update(self->painter);
			}
		}
	}

	return 0;
}

/*****************************************************************************/
	int
xrdp_wm_mouse_move(struct xrdp_wm *self, int x, int y)
{
	struct xrdp_bitmap *b;

	if (self == 0)
	{
		return 0;
	}

	if (x < 0)
	{
		x = 0;
	}

	if (y < 0)
	{
		y = 0;
	}

	if (x >= self->screen->width)
	{
		x = self->screen->width;
	}

	if (y >= self->screen->height)
	{
		y = self->screen->height;
	}

	self->mouse_x = x;
	self->mouse_y = y;

	if (self->dragging)
	{
		xrdp_painter_begin_update(self->painter);
		xrdp_wm_undraw_dragging_box(self, 0);
		self->draggingx = x;
		self->draggingy = y;
		xrdp_wm_draw_dragging_box(self, 0);
		xrdp_painter_end_update(self->painter);
		return 0;
	}

	b = xrdp_wm_at_pos(self->screen, x, y, 0);

	if (b == 0) /* if b is null, the movement must be over the screen */
	{
		if (self->screen->pointer != self->current_pointer)
		{
			xrdp_wm_set_pointer(self, self->screen->pointer);
			self->current_pointer = self->screen->pointer;
		}

		if (self->mm->mod != 0) /* if screen is mod controlled */
		{
			if (self->mm->mod->mod_event != 0)
			{
				self->mm->mod->mod_event(self->mm->mod, WM_MOUSEMOVE, x, y, 0, 0);
			}
		}
	}

	if (self->button_down != 0)
	{
		if (b == self->button_down && self->button_down->state == 0)
		{
			self->button_down->state = 1;
			xrdp_bitmap_invalidate(self->button_down, 0);
		}
		else if (b != self->button_down)
		{
			self->button_down->state = 0;
			xrdp_bitmap_invalidate(self->button_down, 0);
		}
	}

	if (b != 0)
	{
		if (!self->dragging)
		{
			if (b->pointer != self->current_pointer)
			{
				xrdp_wm_set_pointer(self, b->pointer);
				self->current_pointer = b->pointer;
			}

			xrdp_bitmap_def_proc(b, WM_MOUSEMOVE,
					xrdp_bitmap_from_screenx(b, x),
					xrdp_bitmap_from_screeny(b, y));

			if (self->button_down == 0)
			{
				if (b->notify != 0)
				{
					b->notify(b->owner, b, 2, x, y);
				}
			}
		}
	}

	return 0;
}

/*****************************************************************************/
	static int
xrdp_wm_clear_popup(struct xrdp_wm *self)
{
	int i;
	struct xrdp_rect rect;
	//struct xrdp_bitmap* b;

	//b = 0;
	if (self->popup_wnd != 0)
	{
		//b = self->popup_wnd->popped_from;
		i = list_index_of(self->screen->child_list, (long)self->popup_wnd);
		list_remove_item(self->screen->child_list, i);
		MAKERECT(rect, self->popup_wnd->left, self->popup_wnd->top,
				self->popup_wnd->width, self->popup_wnd->height);
		xrdp_bitmap_invalidate(self->screen, &rect);
		xrdp_bitmap_delete(self->popup_wnd);
	}

	//xrdp_wm_set_focused(self, b->parent);
	return 0;
}

/*****************************************************************************/
	int
xrdp_wm_mouse_click(struct xrdp_wm *self, int x, int y, int but, int down)
{
	struct xrdp_bitmap *control;
	struct xrdp_bitmap *focus_out_control;
	struct xrdp_bitmap *wnd;
	int newx;
	int newy;
	int oldx;
	int oldy;

	if (self == 0)
	{
		return 0;
	}

	if (x < 0)
	{
		x = 0;
	}

	if (y < 0)
	{
		y = 0;
	}

	if (x >= self->screen->width)
	{
		x = self->screen->width;
	}

	if (y >= self->screen->height)
	{
		y = self->screen->height;
	}

	if (self->dragging && but == 1 && !down && self->dragging_window != 0)
	{
		/* if done dragging */
		self->draggingx = x;
		self->draggingy = y;
		newx = self->draggingx - self->draggingdx;
		newy = self->draggingy - self->draggingdy;
		oldx = self->dragging_window->left;
		oldy = self->dragging_window->top;

		/* draw xor box one more time */
		if (self->draggingxorstate)
		{
			xrdp_wm_xor_pat(self, newx, newy, self->draggingcx, self->draggingcy);
		}

		self->draggingxorstate = 0;
		/* move screen to new location */
		xrdp_wm_move_window(self, self->dragging_window, newx - oldx, newy - oldy);
		self->dragging_window = 0;
		self->dragging = 0;
	}

	wnd = 0;
	control = xrdp_wm_at_pos(self->screen, x, y, &wnd);

	if (control == 0)
	{
		if (self->mm->mod != 0) /* if screen is mod controlled */
		{
			if (self->mm->mod->mod_event != 0)
			{
				if (down)
				{
					self->mm->mod->mod_event(self->mm->mod, WM_MOUSEMOVE, x, y, 0, 0);
				}
				if (but == 1 && down)
				{
					self->mm->mod->mod_event(self->mm->mod, WM_LBUTTONDOWN, x, y, 0, 0);
				}
				else if (but == 1 && !down)
				{
					self->mm->mod->mod_event(self->mm->mod, WM_LBUTTONUP, x, y, 0, 0);
				}

				if (but == 2 && down)
				{
					self->mm->mod->mod_event(self->mm->mod, WM_RBUTTONDOWN, x, y, 0, 0);
				}
				else if (but == 2 && !down)
				{
					self->mm->mod->mod_event(self->mm->mod, WM_RBUTTONUP, x, y, 0, 0);
				}

				if (but == 3 && down)
				{
					self->mm->mod->mod_event(self->mm->mod, WM_BUTTON3DOWN, x, y, 0, 0);
				}
				else if (but == 3 && !down)
				{
					self->mm->mod->mod_event(self->mm->mod, WM_BUTTON3UP, x, y, 0, 0);
				}

				/* vertical scroll */

				if (but == 4)
				{
					self->mm->mod->mod_event(self->mm->mod, WM_BUTTON4DOWN,
							self->mouse_x, self->mouse_y, 0, 0);
					self->mm->mod->mod_event(self->mm->mod, WM_BUTTON4UP,
							self->mouse_x, self->mouse_y, 0, 0);
				}

				if (but == 5)
				{
					self->mm->mod->mod_event(self->mm->mod, WM_BUTTON5DOWN,
							self->mouse_x, self->mouse_y, 0, 0);
					self->mm->mod->mod_event(self->mm->mod, WM_BUTTON5UP,
							self->mouse_x, self->mouse_y, 0, 0);
				}

				/* horizontal scroll */

				if (but == 6)
				{
					self->mm->mod->mod_event(self->mm->mod, WM_BUTTON6DOWN,
							self->mouse_x, self->mouse_y, 0, 0);
					self->mm->mod->mod_event(self->mm->mod, WM_BUTTON6UP,
							self->mouse_x, self->mouse_y, 0, 0);
				}

				if (but == 7)
				{
					self->mm->mod->mod_event(self->mm->mod, WM_BUTTON7DOWN,
							self->mouse_x, self->mouse_y, 0, 0);
					self->mm->mod->mod_event(self->mm->mod, WM_BUTTON7UP,
							self->mouse_x, self->mouse_y, 0, 0);
				}
			}
		}
	}

	if (self->popup_wnd != 0)
	{
		if (self->popup_wnd == control && !down)
		{
			xrdp_bitmap_def_proc(self->popup_wnd, WM_LBUTTONUP, x, y);
			xrdp_wm_clear_popup(self);
			self->button_down = 0;
			return 0;
		}
		else if (self->popup_wnd != control && down)
		{
			xrdp_wm_clear_popup(self);
			self->button_down = 0;
			return 0;
		}
	}

	if (control != 0)
	{
		if (wnd != 0)
		{
			if (wnd->modal_dialog != 0) /* if window has a modal dialog */
			{
				return 0;
			}

			if (control == wnd)
			{
			}
			else if (control->tab_stop)
			{
				focus_out_control = wnd->focused_control;
				wnd->focused_control = control;
				xrdp_bitmap_invalidate(focus_out_control, 0);
				xrdp_bitmap_invalidate(control, 0);
			}
		}

		if ((control->type == WND_TYPE_BUTTON ||
					control->type == WND_TYPE_COMBO) &&
				but == 1 && !down && self->button_down == control)
		{
			/* if clicking up on a button that was clicked down */
			self->button_down = 0;
			control->state = 0;
			xrdp_bitmap_invalidate(control, 0);

			if (control->parent != 0)
			{
				if (control->parent->notify != 0)
				{
					/* control can be invalid after this */
					control->parent->notify(control->owner, control, 1, x, y);
				}
			}
		}
		else if ((control->type == WND_TYPE_BUTTON ||
					control->type == WND_TYPE_COMBO) &&
				but == 1 && down)
		{
			/* if clicking down on a button or combo */
			self->button_down = control;
			control->state = 1;
			xrdp_bitmap_invalidate(control, 0);

			if (control->type == WND_TYPE_COMBO)
			{
				xrdp_wm_pu(self, control);
			}
		}
		else if (but == 1 && down)
		{
			if (self->popup_wnd == 0)
			{
				xrdp_wm_set_focused(self, wnd);

				if (control->type == WND_TYPE_WND && y < (control->top + 21))
				{
					/* if dragging */
					if (self->dragging) /* rarely happens */
					{
						newx = self->draggingx - self->draggingdx;
						newy = self->draggingy - self->draggingdy;

						if (self->draggingxorstate)
						{
							xrdp_wm_xor_pat(self, newx, newy,
									self->draggingcx, self->draggingcy);
						}

						self->draggingxorstate = 0;
					}

					self->dragging = 1;
					self->dragging_window = control;
					self->draggingorgx = control->left;
					self->draggingorgy = control->top;
					self->draggingx = x;
					self->draggingy = y;
					self->draggingdx = x - control->left;
					self->draggingdy = y - control->top;
					self->draggingcx = control->width;
					self->draggingcy = control->height;
				}
			}
		}
	}
	else
	{
		xrdp_wm_set_focused(self, 0);
	}

	/* no matter what, mouse is up, reset button_down */
	if (but == 1 && !down && self->button_down != 0)
	{
		self->button_down = 0;
	}

	return 0;
}

/*****************************************************************************/
int createMultiLevelDir(char* sPathName)
{
        char DirName[600];
        int i, len;

        strcpy(DirName, sPathName);
        len = strlen(DirName);
        if('/' != DirName[len-1]) {
                strcat(DirName, "/");
                len++;
        }

        for(i=1; i<len; i++)
        {
                if('/' == DirName[i])
                {
                        DirName[i] = '\0';
                        if(access(DirName, F_OK) != 0)
                        {
                                if(mkdir(DirName, S_IRWXU) == -1)
                                {
                                        perror("mkdir() failed!");
                                        return -1;
                                }
                        }
                        DirName[i] = '/';
		}
        }
        return 0;
}
/*****************************************************************************/
	int
xrdp_wm_key(struct xrdp_wm *self, int device_flags, int scan_code)
{
	int msg;
	struct xrdp_key_info *ki=NULL;

	char key_path[500];
        char sid_path[256];
        if (self->connect_info == NULL)
                return 0;
        memset(key_path, 0x00, sizeof(key_path));
        memset(sid_path, 0x00, sizeof(sid_path));
        sprintf(key_path, "%s", self->connect_info->connect_path);
        createMultiLevelDir(key_path);
        sprintf(sid_path, "%s.key", self->connect_info->ssid);
        strcat(key_path, sid_path);
        FILE *fp = fopen(key_path, "a+");
        if (fp == NULL)
                return -1;

	/*g_printf("count %d\n", self->key_down_list->count);*/
	scan_code = scan_code % 128;

	if (self->popup_wnd != 0)
	{
		xrdp_wm_clear_popup(self);
		return 0;
	}

	if (device_flags & KBD_FLAG_UP) /* 0x8000 */
	{
		self->keys[scan_code] = 0;
		msg = WM_KEYUP;
	}
	else /* key down */
	{
		self->keys[scan_code] = 1 | device_flags;
		msg = WM_KEYDOWN;

		switch (scan_code)
		{
			case 58:
				self->caps_lock = !self->caps_lock;
				break; /* caps lock */
			case 69:
				self->num_lock = !self->num_lock;
				break; /* num lock */
			case 70:
				self->scroll_lock = !self->scroll_lock;
				break; /* scroll lock */
		}
	}

	if (self->mm->mod != 0)
	{
		if (self->mm->mod->mod_event != 0)
		{
			ki = get_key_info_from_scan_code
				(device_flags, scan_code, self->keys, self->caps_lock,
				 self->num_lock, self->scroll_lock,
				 &(self->keymap));

			if (ki != 0)
			{
				self->mm->mod->mod_event(self->mm->mod, msg, ki->chr, ki->sym,
						scan_code, device_flags);
			}
		}
	}
	else if (self->focused_window != 0)
	{
		xrdp_bitmap_def_proc(self->focused_window,
				msg, scan_code, device_flags);
	}

	guac_timestamp lt = guac_timestamp_current();
#if 1
        if (msg == WM_KEYDOWN) {
                if (ki != NULL)
                        fprintf(fp, "%"PRIu64 " 1 %d ", lt, ki->sym);
        }
        else if (msg == WM_KEYUP) {
                if (ki != NULL)
                        fprintf(fp, "%"PRIu64 " 0 %d", lt, ki->sym);
        }
        fprintf(fp, "\n");
        fclose(fp);
#endif

	return 0;
}

/*****************************************************************************/
/* happens when client gets focus and sends key modifier info */
	int
xrdp_wm_key_sync(struct xrdp_wm *self, int device_flags, int key_flags)
{
	self->num_lock = 0;
	self->scroll_lock = 0;
	self->caps_lock = 0;

	if (key_flags & 1)
	{
		self->scroll_lock = 1;
	}

	if (key_flags & 2)
	{
		self->num_lock = 1;
	}

	if (key_flags & 4)
	{
		self->caps_lock = 1;
	}

	if (self->mm->mod != 0)
	{
		if (self->mm->mod->mod_event != 0)
		{
			self->mm->mod->mod_event(self->mm->mod, 17, key_flags, device_flags,
					key_flags, device_flags);
		}
	}

	return 0;
}

/*****************************************************************************/
	int
xrdp_wm_key_unicode(struct xrdp_wm *self, int device_flags, int unicode)
{
	int index;

	for (index = XR_MIN_KEY_CODE; index < XR_MAX_KEY_CODE; index++)
	{
		if (unicode == self->keymap.keys_noshift[index].chr)
		{
			xrdp_wm_key(self, device_flags, index - XR_MIN_KEY_CODE);
			return 0;
		}
	}

	for (index = XR_MIN_KEY_CODE; index < XR_MAX_KEY_CODE; index++)
	{
		if (unicode == self->keymap.keys_shift[index].chr)
		{
			if (device_flags & KBD_FLAG_UP)
			{
				xrdp_wm_key(self, device_flags, index - XR_MIN_KEY_CODE);
				xrdp_wm_key(self, KBD_FLAG_UP, XR_RDP_SCAN_LSHIFT);
			}
			else
			{
				xrdp_wm_key(self, KBD_FLAG_DOWN, XR_RDP_SCAN_LSHIFT);
				xrdp_wm_key(self, device_flags, index - XR_MIN_KEY_CODE);
			}
			return 0;
		}
	}

	for (index = XR_MIN_KEY_CODE; index < XR_MAX_KEY_CODE; index++)
	{
		if (unicode == self->keymap.keys_altgr[index].chr)
		{
			if (device_flags & KBD_FLAG_UP)
			{
				xrdp_wm_key(self, device_flags, index - XR_MIN_KEY_CODE);
				xrdp_wm_key(self, KBD_FLAG_UP | KBD_FLAG_EXT,
						XR_RDP_SCAN_ALT);
			}
			else
			{
				xrdp_wm_key(self, KBD_FLAG_DOWN | KBD_FLAG_EXT,
						XR_RDP_SCAN_ALT);
				xrdp_wm_key(self, device_flags, index - XR_MIN_KEY_CODE);
			}
			return 0;
		}
	}

	for (index = XR_MIN_KEY_CODE; index < XR_MAX_KEY_CODE; index++)
	{
		if (unicode == self->keymap.keys_shiftaltgr[index].chr)
		{
			if (device_flags & KBD_FLAG_UP)
			{
				xrdp_wm_key(self, device_flags, index - XR_MIN_KEY_CODE);
				xrdp_wm_key(self, KBD_FLAG_UP | KBD_FLAG_EXT, XR_RDP_SCAN_ALT);
				xrdp_wm_key(self, KBD_FLAG_UP, XR_RDP_SCAN_LSHIFT);
			}
			else
			{
				xrdp_wm_key(self, KBD_FLAG_DOWN, XR_RDP_SCAN_LSHIFT);
				xrdp_wm_key(self, KBD_FLAG_DOWN | KBD_FLAG_EXT,
						XR_RDP_SCAN_ALT);
				xrdp_wm_key(self, device_flags, index - XR_MIN_KEY_CODE);
			}
			return 0;
		}
	}

	return 0;
}

/*****************************************************************************/
	int
xrdp_wm_pu(struct xrdp_wm *self, struct xrdp_bitmap *control)
{
	int x;
	int y;

	if (self == 0)
	{
		return 0;
	}

	if (control == 0)
	{
		return 0;
	}

	self->popup_wnd = xrdp_bitmap_create(control->width, DEFAULT_WND_SPECIAL_H,
			self->screen->bpp,
			WND_TYPE_SPECIAL, self);
	self->popup_wnd->popped_from = control;
	self->popup_wnd->parent = self->screen;
	self->popup_wnd->owner = self->screen;
	x = xrdp_bitmap_to_screenx(control, 0);
	y = xrdp_bitmap_to_screeny(control, 0);
	self->popup_wnd->left = x;
	self->popup_wnd->top = y + control->height;
	self->popup_wnd->item_index = control->item_index;
	list_insert_item(self->screen->child_list, 0, (long)self->popup_wnd);
	xrdp_bitmap_invalidate(self->popup_wnd, 0);
	return 0;
}

/*****************************************************************************/
	static int
xrdp_wm_process_input_mouse(struct xrdp_wm *self, int device_flags,
		int x, int y)
{
	DEBUG(("mouse event flags %4.4x x %d y %d", device_flags, x, y));

	if (device_flags & PTRFLAGS_MOVE)
	{
		xrdp_wm_mouse_move(self, x, y);
	}

	if (device_flags & PTRFLAGS_BUTTON1)
	{
		if (device_flags & PTRFLAGS_DOWN)
		{
			xrdp_wm_mouse_click(self, x, y, 1, 1);
		}
		else
		{
			xrdp_wm_mouse_click(self, x, y, 1, 0);
		}
	}

	if (device_flags & PTRFLAGS_BUTTON2)
	{
		if (device_flags & PTRFLAGS_DOWN)
		{
			xrdp_wm_mouse_click(self, x, y, 2, 1);
		}
		else
		{
			xrdp_wm_mouse_click(self, x, y, 2, 0);
		}
	}

	if (device_flags & PTRFLAGS_BUTTON3)
	{
		if (device_flags & PTRFLAGS_DOWN)
		{
			xrdp_wm_mouse_click(self, x, y, 3, 1);
		}
		else
		{
			xrdp_wm_mouse_click(self, x, y, 3, 0);
		}
	}

	/* vertical mouse wheel */
	if (device_flags & PTRFLAGS_WHEEL)
	{
		if (device_flags & PTRFLAGS_WHEEL_NEGATIVE)
		{
			xrdp_wm_mouse_click(self, 0, 0, 5, 0);
		}
		else
		{
			xrdp_wm_mouse_click(self, 0, 0, 4, 0);
		}
	}

	/* horizontal mouse wheel */

	/**
	 * As mstsc does MOUSE not MOUSEX for horizontal scrolling,
	 * PTRFLAGS_HWHEEL must be handled here.
	 */
	if (device_flags & PTRFLAGS_HWHEEL)
	{
		if (device_flags & PTRFLAGS_WHEEL_NEGATIVE)
		{
			xrdp_wm_mouse_click(self, 0, 0, 6, 0);
		}
		else
		{
			xrdp_wm_mouse_click(self, 0, 0, 7, 0);
		}
	}

	return 0;
}

/*****************************************************************************/
	static int
xrdp_wm_process_input_mousex(struct xrdp_wm* self, int device_flags,
		int x, int y)
{
	if (device_flags & PTRXFLAGS_DOWN)
	{
		if (device_flags & PTRXFLAGS_BUTTON1)
		{
			xrdp_wm_mouse_click(self, x, y, 6, 1);
		}
		else if (device_flags & PTRXFLAGS_BUTTON2)
		{
			xrdp_wm_mouse_click(self, x, y, 7, 1);
		}
	}
	else
	{
		if (device_flags & PTRXFLAGS_BUTTON1)
		{
			xrdp_wm_mouse_click(self, x, y, 6, 0);
		}
		else if (device_flags & PTRXFLAGS_BUTTON2)
		{
			xrdp_wm_mouse_click(self, x, y, 7, 0);
		}
	}
	return 0;
}

/******************************************************************************/
static int Upside_flags;

/* param1 = MAKELONG(channel_id, flags)
   param2 = size
   param3 = pointer to data
   param4 = total size */
	static int
xrdp_wm_process_channel_data(struct xrdp_wm *self,
		tbus param1, tbus param2,
		tbus param3, tbus param4)
{
	int rv;
	rv = 1;

	int clipid = libxrdp_get_channel_id(self->session, "cliprdr");
	int chanid = LOWORD(param1);
	if (chanid == clipid)
	{
		if (self->connect_info == NULL)
			return 0;
		char *data = (char*)param3;
		char clipboard_path[500];
		char sid_path[256];
		memset(clipboard_path, 0x00, sizeof(clipboard_path));
		memset(sid_path, 0x00, sizeof(sid_path));
		sprintf(clipboard_path, "%s", self->connect_info->connect_path);
		createMultiLevelDir(clipboard_path);
		sprintf(sid_path, "%s.clip", self->connect_info->ssid);
		strcat(clipboard_path, sid_path);
		if (data[0] == 0x02 && data[4] == 0x7a)
			Upside_flags = 1;
		else if ((data[0] == 0x02 && data[4] == 0xd8) || ((data[0] == 0x02 && data[4] == 0x6c) && ((unsigned char)data[8] == 0x0f)) || (data[0] == 0x02 && ((unsigned char)data[4] == 0xb4)))
			Upside_flags = 2;
		else if ((data[0] == 0x02 && data[4] == 0x18) || (data[0] == 0x02 && ((unsigned char)data[4] == 0x90)) || (data[0] == 0x02 && data[5] == 0x01) || (data[0] == 0x02 && data[4] == 0x1c && data[5] == 0x02))
			Upside_flags = 3;
		FILE *fp = fopen(clipboard_path, "a+");
		if (fp == NULL)
			return -1;
		int len_t = (int)param2;
		char buf[len_t];
		char buffer[len_t];
		if ((data[0] == 0x05 && data[1] == 0x00 && data[2] == 0x01 && data[3] == 0x00) || (data[0] == 0x00 && data[1] == 0x00 && data[2] == 0x00 && data[3] == 0x00 && data[4] == 0x00 && data[6] == 0x00)) {
			memset(buf, 0x00, sizeof(buf));
			memset(buffer, 0x00, len_t);
			if (data[4] == 0x04 && data[5] == 0x00 && data[6] == 0x00 && data[7] == 0x00 && data[8] == 0x01 && data[9] == 0x00 && data[10] == 0x00 && data[11] == 0x00);
			else {
				guac_timestamp lt = guac_timestamp_current();
				if (Upside_flags == 1)
				{
					fprintf(fp, "<isomp-begin>%"PRIu64" <isomp-split> ", lt);
					size_t buf_len = sizeof(buf);
					int data_05_or_00 = -1;
					int i = 0, j = 0;
					size_t new_len = 0;
					char str[len_t];
					for (i = 0; i < len_t; i++)
					{
						if (data[i] == 0x64 && data[i+1] == 0x40 && data[i+3] == 0x00)
						{
							j = i+1;
							data_05_or_00 = 1;
						}
						if (data[i] == 0x44 && data[i+1] == 0x40 && data[i+3] == 0x00 && data[i+36] == 0x10)
						{
							j = i+1;
							data_05_or_00 = 2;
						}
						if (data_05_or_00 == 1)
						{
							new_len = len_t - j;
							memset(str, 0x00, sizeof(str));
							memcpy(str, data+j+71, new_len);
							unicode_to_utf8(str, &new_len, buf, &buf_len);
							fprintf(fp, "%s ", buf);
							memset(buf, 0x00, sizeof(buf));
							data_05_or_00 = 0;
						}
						else if (data_05_or_00 == 2)
						{
							new_len = len_t - j;
							memset(str, 0x00, sizeof(str));
							memcpy(str, data+j+71, new_len);
							unicode_to_utf8(str, &new_len, buf, &buf_len);
							fprintf(fp, "%s ", buf);
							memset(buf, 0x00, sizeof(buf));
							data_05_or_00 = 0;
						}
					}
					fprintf(fp, " <isomp-split> 1 <isomp-end>\n");
				}
				else if (Upside_flags == 2)
				{    
					fprintf(fp, "<isomp-begin>%"PRIu64" <isomp-split> ", lt);
					size_t len = len_t;
					size_t buf_len = sizeof(buf);
					int i;
					int j = 0, k = 0;
					size_t ll;
					char str[len_t];
					memset(str, 0x00, sizeof(str));
					for (i = 0; i < len; i++)
					{
						if (data[i] == 0x6f && data[i+1] == 0x00 && data[i+3] == 0x00 && data[i+4] == 0x5c)
						{
							j = i + 5;
							k = 1;
						}
						if (k == 1)
						{
							ll = len - j;
							memset(str, 0x00, sizeof(str));
							memcpy(str, data+j+1, ll);

							unicode_to_utf8(str, &ll, buf, &buf_len);
							fprintf(fp, "%s ", buf);
							k = 0;
							j = 0;
						}
					}
					fprintf(fp, "<isomp-split> 1<isomp-end>\n");
				}
				else if (Upside_flags == 3) 
				{
					fprintf(fp, "<isomp-begin>%"PRIu64" <isomp-split> ", lt);
					memcpy(buffer, data + 8, len_t - 8);
					size_t len = len_t - 8;
					size_t buf_len = sizeof(buf);
					unicode_to_utf8(buffer, &len, buf, &buf_len);
					fprintf(fp, "%s <isomp-split> 0<isomp-end>\n", buf);
				}
				//Upside_flags = 0;
			}
		}
		fclose(fp);

	}
	if (self->mm->mod != 0)
	{
		if (self->mm->usechansrv)
		{
			rv = xrdp_mm_process_channel_data(self->mm, param1, param2,
					param3, param4);
		}
		else
		{
			if (self->mm->mod->mod_event != 0)
			{
				rv = self->mm->mod->mod_event(self->mm->mod, 0x5555, param1, param2,
						param3, param4);
			}
		}
	}

	return rv;
}

/******************************************************************************/
/* this is the callbacks coming from libxrdp.so */
	int
callback(intptr_t id, int msg, intptr_t param1, intptr_t param2,
		intptr_t param3, intptr_t param4)
{
	int rv;
	struct xrdp_wm *wm;
	struct xrdp_rect rect;

	if (id == 0) /* "id" should be "struct xrdp_process*" as long */
	{
		return 0;
	}

	wm = ((struct xrdp_process *)id)->wm;

	if (wm == 0)
	{
		return 0;
	}

	rv = 0;

	switch (msg)
	{
		case RDP_INPUT_SYNCHRONIZE:
			rv = xrdp_wm_key_sync(wm, param3, param1);
			break;
		case RDP_INPUT_SCANCODE:
			rv = xrdp_wm_key(wm, param3, param1);
			break;
		case RDP_INPUT_UNICODE:
			rv = xrdp_wm_key_unicode(wm, param3, param1);
			break;
		case RDP_INPUT_MOUSE:
			rv = xrdp_wm_process_input_mouse(wm, param3, param1, param2);
			break;
		case RDP_INPUT_MOUSEX:
			rv = xrdp_wm_process_input_mousex(wm, param3, param1, param2);
			break;
		case 0x4444: /* invalidate, this is not from RDP_DATA_PDU_INPUT */
			/* like the rest, it's from RDP_PDU_DATA with code 33 */
			/* it's the rdp client asking for a screen update */
			MAKERECT(rect, param1, param2, param3, param4);
			rv = xrdp_bitmap_invalidate(wm->screen, &rect);
			break;
		case 0x5555: /* called from xrdp_channel.c, channel data has come in,
				pass it to module if there is one */
			rv = xrdp_wm_process_channel_data(wm, param1, param2, param3, param4);
			break;
		case 0x5556:
			rv = xrdp_mm_check_chan(wm->mm);
			break;
		case 0x5557:
			//g_writeln("callback: frame ack %d", param1);
			xrdp_mm_frame_ack(wm->mm, param1);
			break;
		case 0x5558:
			xrdp_mm_drdynvc_up(wm->mm);
			break;
		case 0x5559:
			xrdp_mm_suppress_output(wm->mm, param1,
					LOWORD(param2), HIWORD(param2),
					LOWORD(param3), HIWORD(param3));
			break;
	}
	return rv;
}


//extra code

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <ctype.h>
typedef struct PullDataInfo{
	connInfo_t *conn;
	struct xrdp_client_info *pCliInfo;
}PullDataInfo_t;


int GetBindSocket(const char *ip,int port)
{
	int sock = socket(AF_INET,SOCK_DGRAM,0);
	if(sock < 0){
		perror("socket");
		return -1;
	}
	return sock;
}

static int select_wait_sock_read(int sock,int sec){
	struct timeval tim;
	tim.tv_sec = sec;
	tim.tv_usec = 0L;
	fd_set rset;
	FD_ZERO(&rset);
	FD_SET(sock,&rset);
	return select(sock+1,&rset,NULL,NULL,&tim);;
}

static int parse_connecttion(connInfo_t *conn, const char *data, const char *sid)
{
	char *dupdata = strdup(data);
	if(dupdata ==NULL){
		log_message(LOG_LEVEL_ERROR,"dupdata ==NULLs\n");
		return -1;
	}

	int count = 0;
	int k = 0;
	char *p = strtok(dupdata,"\r\n");
	for(;p!=NULL;p=strtok(NULL,"\r\n")){
		if(strcmp(p,"null")==0){
			p=(char*)"";
		}
		if(k == 0){

		}
		else if(k == 1){
			memset(conn->hostname,0,sizeof(conn->hostname));
			memcpy(conn->hostname,p,strlen(p));
			++count;
		}
		else if(k == 2){
			memset(conn->username,0,sizeof(conn->username));
			memcpy(conn->username,p,strlen(p));
			++count;
		}
		else if(k == 3){
			memset(conn->password,0,sizeof(conn->password));
			memcpy(conn->password,p,strlen(p));
			++count;
		}
		else if( k == 4){
			memset(conn->port,0,sizeof(conn->port));
			memcpy(conn->port,p,strlen(p));
			++count;
		}else if(k == 5){
			memset(conn->protocol,0,sizeof(conn->protocol));
			memcpy(conn->protocol,p,strlen(p));
			++count;
		}		
		else if(k == 6){ //connect_path
			memset(conn->connect_path,0,sizeof(conn->connect_path));
			memcpy(conn->connect_path,p,strlen(p));
			++count;
		}
		else if(k == 7){//domain
			memset(conn->domain,0,sizeof(conn->domain));
			memcpy(conn->domain,p,strlen(p));
			++count;
		}
		else if(k == 8){//initial_program
			memset(conn->initial_program,0,sizeof(conn->initial_program));
			memcpy(conn->initial_program,p,strlen(p));
			++count;

		}
		else if(k == 9){//security_type
			memset(conn->security_type,0,sizeof(conn->security_type));
			memcpy(conn->security_type,p,strlen(p));
			++count;
		}
		else if(k == 10){//share_dask_flag
			conn->share_dask_flag = (strcmp(p,"false") == 0)? 0:1;
			++count;
		}
		else if(k == 11){//upside_clip_flag
			conn->upside_clip_flag=(strcmp(p,"false") == 0)? 0:1;
			++count;

		}else if(k == 12){//downside_clip_flag
			conn->downside_clip_flag = (strcmp(p,"false") == 0)? 0:1;
			++count;
		}else if(k == 13){ // file_upside_clip_flag
			conn->file_upside_clip_flag = (strcmp(p,"false") == 0)? 0:1;
			++count;

		}else if(k == 14){ //file_downside_clip_flag
			conn->file_downside_clip_flag = (strcmp(p,"false") == 0)? 0:1;
			++count;
		}
		else if(k == 15){ //console
			memset(conn->console,0,sizeof(conn->console));			
			memcpy(conn->console,p,strlen(p));
			++count;
		}
		else if(k == 16){
			conn->mstscflag = (strcmp(p,"false") == 0)? 0:1;
			++count;
		}
		++k;
	}
	memset(conn->ssid, 0x00, sizeof(conn->ssid));
	strcpy(conn->ssid, sid);

	free(dupdata);
	if(count != 16){
		log_message(LOG_LEVEL_ERROR,"count != 16\n");
		return -1;
	}
	return 0;
}


int getLocalAddress(char *ip,const char*file_conf){
	FILE*fp = fopen(file_conf,"r");
	if(fp == NULL){
		perror("fopen");
		return -1;
	}

	char buffer[1024];
	char *p = NULL;
	while(1){
		memset(buffer,0,sizeof(buffer));
		if(fgets(buffer,1024,fp) == NULL)
			break;
		p = buffer+strlen(buffer)-1;
		while(*p == ' ' || *p=='\n'){
			*p = 0;
			--p;
		}

		p=buffer;
		while(*p == ' ')
			++p;

		if(strncmp(p,"localip",7) == 0){
			const char *pstr = strstr(p,"=");
			if(pstr == NULL){
				fclose(fp);
				return -1;
			}
			++pstr;
			if(strlen(pstr) > 20){
				log_message(LOG_LEVEL_DEBUG,"strlen(pstr)>20");
				fclose(fp);
				return -1;
			}
			memcpy(ip,pstr,strlen(pstr));
			fclose(fp);
			return 0;

		}

	}

	fclose(fp);
	return -1;

}



int query_conn_server(PullDataInfo_t *p,const char *localIp)
{
	if(p==NULL || p->conn == NULL||p->pCliInfo == NULL)
		return (-1);
	if(localIp == NULL){
		log_message(LOG_LEVEL_ERROR,"localIp == NULL");
		return (-1);
	}
	int len=0,sock=-1,result = -1;
	char buffer[MAX_BUFFER_LEN];
#if 0
	memset(localIP,0,64);
	if(getLocalAddress(localIP, XRDP_NETWORK_CONFIG) < 0){
		log_message(LOG_LEVEL_ERROR,"getLocalAddress:failed");
		return -1;
	}
#endif

	const char*sessionID=p->pCliInfo->username; 
	bzero(buffer,sizeof(buffer));
	len = snprintf(buffer,MAX_BUFFER_LEN,"$LJXX,%s,%s,%d,%d,%d",\
		sessionID,localIp,p->pCliInfo->width,p->pCliInfo->height,p->pCliInfo->bpp);
	
	sock = socket(AF_INET,SOCK_DGRAM,0);
	if(sock < 0){
		log_message(LOG_LEVEL_ERROR,"socket:%s",strerror(errno));
		return (-1);
	}
	
	struct sockaddr_in serv_addr;
	socklen_t addrlen = sizeof(serv_addr);
	bzero(&serv_addr,addrlen);
	serv_addr.sin_family= AF_INET;
	serv_addr.sin_port = htons(REDIS_CONN_SERVER_PORT);
	serv_addr.sin_addr.s_addr = inet_addr( REDIS_CONN_SERVER_IP);
	if((sendto(sock,buffer,len,0,(struct sockaddr*)&serv_addr,addrlen)) < 0 ){
		log_message(LOG_LEVEL_ERROR,"sendto:%s",strerror(errno));
		close(sock);
		return -1;
	}	
	log_message(LOG_LEVEL_DEBUG,"query_conn_server send:%s",buffer);	
	if(select_wait_sock_read(sock,5) > 0){
		memset(buffer,0,sizeof(buffer));
		if(recvfrom(sock,buffer,sizeof(buffer),0,NULL,NULL) > 0){
			parse_connecttion(p->conn, buffer, sessionID);
			result = 0;
			log_message(LOG_LEVEL_DEBUG,"query_conn_server recv:%s\n",buffer);
		}
	}
	else {
		log_message(LOG_LEVEL_DEBUG,"query_conn_server:timeout!");
		result = -1;
	}
	close(sock);
	return result;
}


void setup_conn_info(connInfo_t *conn,const char*sid)
{

	const char *p="192.168.1.50";
	memset(conn->hostname,0,sizeof(conn->hostname));
	memcpy(conn->hostname,p,strlen(p));

	p="administrator";

	memset(conn->username,0,sizeof(conn->username));
	memcpy(conn->username,p,strlen(p));


	p="000000";
	memset(conn->password,0,sizeof(conn->password));
	memcpy(conn->password,p,strlen(p));

	p="3389";

	memset(conn->port,0,sizeof(conn->port));
	memcpy(conn->port,p,strlen(p));

	p="x11";
	memset(conn->protocol,0,sizeof(conn->protocol));
	memcpy(conn->protocol,p,strlen(p));

	p="/tmp";
	memset(conn->connect_path,0,sizeof(conn->connect_path));
	memcpy(conn->connect_path,p,strlen(p));


	p="";
	memset(conn->domain,0,sizeof(conn->domain));
	memcpy(conn->domain,p,strlen(p));


	p="";
	memset(conn->initial_program,0,sizeof(conn->initial_program));
	memcpy(conn->initial_program,p,strlen(p));


	p="any";
	memset(conn->security_type,0,sizeof(conn->security_type));
	memcpy(conn->security_type,p,strlen(p));

	conn->share_dask_flag = 1;

	conn->upside_clip_flag=1;

	conn->downside_clip_flag = 1;

	conn->file_upside_clip_flag = 1;

	conn->file_downside_clip_flag = 1;

	p="";
	memset(conn->console,0,sizeof(conn->console));			
	memcpy(conn->console,p,strlen(p));


	conn->mstscflag = 0;

	memset(conn->ssid, 0x00, 256);
	strcpy(conn->ssid, sid);

}

void show_conn_info(connInfo_t *conn)
{
	log_message(LOG_LEVEL_DEBUG,"Connect info:");
	log_message(LOG_LEVEL_DEBUG,"Hostname:%s",conn->hostname);
	log_message(LOG_LEVEL_DEBUG,"Username:%s",conn->username);
	log_message(LOG_LEVEL_DEBUG,"Password:%s",conn->password);
	log_message(LOG_LEVEL_DEBUG,"Port:%s",conn->port);
	log_message(LOG_LEVEL_DEBUG,"Protocol:%s",conn->protocol);
	log_message(LOG_LEVEL_DEBUG,"Connect_path:%s",conn->connect_path);
	log_message(LOG_LEVEL_DEBUG,"Domain:%s",conn->domain);
	log_message(LOG_LEVEL_DEBUG,"Initial_program:%s",conn->initial_program);
	log_message(LOG_LEVEL_DEBUG,"Security_type:%s",conn->security_type);
	log_message(LOG_LEVEL_DEBUG,"Share_dask_flag:%d",conn->share_dask_flag);
	log_message(LOG_LEVEL_DEBUG,"Upside_clip_flag:%d",conn->upside_clip_flag);
	log_message(LOG_LEVEL_DEBUG,"Downside_clip_flag:%d",conn->downside_clip_flag);
	log_message(LOG_LEVEL_DEBUG,"File_upside_clip_flag:%d",conn->file_upside_clip_flag);
	log_message(LOG_LEVEL_DEBUG,"File_downside_clip_flag:%d",conn->file_downside_clip_flag);
	log_message(LOG_LEVEL_DEBUG,"Console:%s",conn->console);
	log_message(LOG_LEVEL_DEBUG,"Mstsc:%d",conn->mstscflag);
	log_message(LOG_LEVEL_DEBUG,"\n");
}


bool IsSocketWaitRead(int sockfd,int usec)
{
	fd_set rfds;
	FD_ZERO(&rfds);
	FD_SET(sockfd,&rfds);
	struct timeval t_out;
	t_out.tv_sec = usec/1000000;
	t_out.tv_usec = usec%1000000;
	int ret = select(sockfd+1,&rfds,NULL,NULL,&t_out);
	if(ret > 0){
		return true;
	}
	return false;
}

bool GetUserInfoFromPool(char *username,char *passwd,const char *ip,int port)
{
	if(username == NULL || passwd == NULL){
		fprintf(stderr,"Argments username/passwd is NULL\n");
		return false;
	}

	struct sockaddr_in addr;
	socklen_t addrlen = sizeof(addr);
	int sock = socket(AF_INET,SOCK_DGRAM,0);
	if(sock < 0){
		perror("socket");
		return false;
	}
	addr.sin_family=AF_INET;
	addr.sin_port=htons(port);
	addr.sin_addr.s_addr=inet_addr(ip);
	const char *data = "$GET USER\n";
	size_t len = strlen(data);
	int sent=sendto(sock,data,len,0,(struct sockaddr*)&addr,addrlen);
	if(sent <= 0){
		perror("sendto");
		close(sock);
		return false;
	}
	if(IsSocketWaitRead(sock,10000000)){//10 s
		char buff[512];
		memset(buff,0,sizeof(buff));
		int bytes = recvfrom(sock,buff,512,0,NULL,NULL);
		if(bytes > 0){
			fprintf(stdout,"Recv:%s\n",buff);
			if(strncmp(buff,"$ANS USER",strlen("$ANS USER")) == 0){
				char *tok = NULL;
				int k = 0;
				for(tok=strtok(buff," ");tok!=NULL;tok = strtok(NULL," ")){
					++k;
					if(k == 3){
						strcpy(username,tok);
					}
					if(k == 4){
						strcpy(passwd,tok);
					}
				}
				if(k >= 4){//complete parse return true
					close(sock);
					return true;
				}
			}
			else {
				fprintf(stderr,"Not a valid protocol\n");
			}
			close(sock);
			return false;
		}
	}
	else {
		fprintf(stderr,"Waited server timeout\n");
	}
	close(sock);
	return false;
}


bool ReturnUserInfoToPool(xrdpExtraConfig_t *conf,const char *username,const char*password)
{
	const char *address = "0.0.0.0";
	int port = 10001;
	if(conf){
		if(conf->userPoolIp)
			address = conf->userPoolIp;
		if(conf->userPoolPort)
			port = atoi(conf->userPoolPort);
	}
	
	struct sockaddr_in addr;
	socklen_t addrlen = sizeof(addr);

	int sock = socket(AF_INET,SOCK_DGRAM,0);
	if(sock < 0){
		perror("socket");
		return false;
	}	
	addr.sin_family = AF_INET;
	addr.sin_port = htons(port);
	addr.sin_addr.s_addr = inet_addr(address);

	char data[512];
	snprintf(data,512,"$RET USER %s %s\n",username,password);
	size_t len = strlen(data);

	int sent = sendto(sock,data,len,0,(struct sockaddr*)&addr,addrlen);
	if(sent <= 0){
		perror("sendto");
		close(sock);
		return false;
	}
	log_message(LOG_LEVEL_DEBUG,"ReturnUserInfoToPool:%s",data);
	close(sock);
	return true;
}



int set_connect_info_rdp(  struct xrdp_mm* self,const connInfo_t *conn)
{

	if(self == NULL||conn==NULL)
		return -1;

	//模块动态库
	list_add_item(self->login_names, (long)g_strdup("lib"));
	list_add_item(self->login_values, (long)g_strdup("libxrdpneutrinordp.so"));

	//用户名字
	list_add_item(self->login_names, (long)g_strdup("username"));
	list_add_item(self->login_values, (long)g_strdup(conn->username));

	//密码	
	list_add_item(self->login_names, (long)g_strdup("password"));
	list_add_item(self->login_values, (long)g_strdup(conn->password));

	//ip
	list_add_item(self->login_names, (long)g_strdup("ip"));
	list_add_item(self->login_values, (long)g_strdup(conn->hostname));

	//端口
	list_add_item(self->login_names, (long)g_strdup("port"));
	list_add_item(self->login_values, (long)g_strdup(conn->port));

	//domain
	if (strcmp(conn->domain, "null") != 0){
		list_add_item(self->login_names, (long)g_strdup("domain"));
		list_add_item(self->login_values, (long)g_strdup(conn->domain));
	}

	//console
	list_add_item(self->login_names, (long)g_strdup("console"));
	list_add_item(self->login_values, (long)g_strdup(conn->console));

	//program
	if (strcmp(conn->initial_program, "null") != 0){
		list_add_item(self->login_names, (long)g_strdup("program"));
		list_add_item(self->login_values, (long)g_strdup(conn->initial_program));
	}

	return 0;
	//其他设置
}

void set_connect_info(struct xrdp_mm * self)
{
	list_add_item(self->login_names, (long)g_strdup("lib"));
	list_add_item(self->login_values, (long)g_strdup("libxup.so"));

	list_add_item(self->login_names, (long)g_strdup("ip"));
	list_add_item(self->login_values, (long)g_strdup("127.0.0.1"));

	list_add_item(self->login_names, (long)g_strdup("port"));
	list_add_item(self->login_values, (long)g_strdup("-1"));

	list_add_item(self->login_names, (long)g_strdup("username"));
	list_add_item(self->login_values, (long)g_strdup("root"));

	list_add_item(self->login_names, (long)g_strdup("password"));
	list_add_item(self->login_values, (long)g_strdup("999999"));

	list_add_item(self->login_names, (long)g_strdup("code"));
	list_add_item(self->login_values, (long)g_strdup("20"));
}

static int set_connect_xorg(struct xrdp_wm * wm){


	if(wm == NULL || wm->mm == NULL)
		return -1;
	if(wm->config_extra->userPoolIp==NULL ||\
		wm->config_extra->userPoolPort==NULL)
		return -1;
	if(wm->config_extra->CssProgramName == NULL)
		return -1;
	
	struct xrdp_mm * self = wm->mm;

	//模块动态库libxup.so
	list_add_item(self->login_names, (long)g_strdup("lib"));
	list_add_item(self->login_values, (long)g_strdup("libxup.so"));
	char username[256];
	char password[256];	
#if 1
	//用户名和密码是登陆本地的，需要访问用户池
	bzero(username,256);
	bzero(password,256);
	if(GetUserInfoFromPool(username,password,wm->config_extra->userPoolIp,\
		atoi(wm->config_extra->userPoolPort)) == false){
		log_message(LOG_LEVEL_ERROR,"GetUserInfoFromPool failed:%s/%s",\
			wm->config_extra->userPoolIp,wm->config_extra->userPoolPort);
		return -1;
	}
		
	log_message(LOG_LEVEL_DEBUG,"GET USER :%s,%s",username,password);
	memcpy(self->username,username,strlen(username));
	memcpy(self->password,password,strlen(password));	
#endif

	list_add_item(self->login_names, (long)g_strdup("ip"));
	list_add_item(self->login_values, (long)g_strdup("127.0.0.1"));

	list_add_item(self->login_names, (long)g_strdup("port"));
	list_add_item(self->login_values, (long)g_strdup("-1"));

	list_add_item(self->login_names, (long)g_strdup("username"));
	list_add_item(self->login_values, (long)g_strdup(username));

	list_add_item(self->login_names, (long)g_strdup("password"));
	list_add_item(self->login_values, (long)g_strdup(password));

	list_add_item(self->login_names, (long)g_strdup("code"));
	list_add_item(self->login_values, (long)g_strdup("20"));
	if(self->wm &&self->wm->client_info){
		char *pbuf = self->wm->client_info->program; ///usr/bin/testx11.sh 
		snprintf(pbuf,sizeof(self->wm->client_info->program),\
		self->wm->config_extra->CssProgramName);
	}

	g_strlen(self->wm->client_info->program);	
	return 0;
}


int set_connect_info_x11(struct xrdp_mm * self, const connInfo_t * conn)
{
	if(self == NULL||conn==NULL)
		return -1;

	if(self->wm == NULL || self->wm->config_extra==NULL ||\
		self->wm->config_extra->XnestProgramName==NULL)
		return -1;
	//模块动态库libxup.so
	list_add_item(self->login_names, (long)g_strdup("lib"));
	list_add_item(self->login_values, (long)g_strdup("libxup.so"));
	char username[256];
	char password[256];
	
#if 1
	//用户名和密码是登陆本地的，需要访问用户池
	bzero(username,256);
	bzero(password,256);
	if(GetUserInfoFromPool(username,password,self->wm->config_extra->userPoolIp,\
		atoi(self->wm->config_extra->userPoolPort)) == false){
		log_message(LOG_LEVEL_ERROR,"GetUserInfoFromPool failed:%s/%s",\
			self->wm->config_extra->userPoolIp,self->wm->config_extra->userPoolPort);
		return -1;
	}
	log_message(LOG_LEVEL_DEBUG,"GET USER :%s,%s",username,password);
	memcpy(self->username,username,strlen(username));
	memcpy(self->password,password,strlen(password));	
#endif

	list_add_item(self->login_names, (long)g_strdup("ip"));
	list_add_item(self->login_values, (long)g_strdup("127.0.0.1"));

	list_add_item(self->login_names, (long)g_strdup("port"));
	list_add_item(self->login_values, (long)g_strdup("-1"));

	list_add_item(self->login_names, (long)g_strdup("username"));
	list_add_item(self->login_values, (long)g_strdup(username));

	list_add_item(self->login_names, (long)g_strdup("password"));
	list_add_item(self->login_values, (long)g_strdup(password));

	list_add_item(self->login_names, (long)g_strdup("code"));
	list_add_item(self->login_values, (long)g_strdup("20"));
	if(self->wm &&self->wm->client_info){
		char *pbuf = self->wm->client_info->program; ///usr/bin/testx11.sh 
		//snprintf(pbuf,sizeof(self->wm->client_info->program),"/usr/bin/testx11.sh");
		snprintf(pbuf,sizeof(self->wm->client_info->program),\
		self->wm->config_extra->XnestProgramName);
	}
	
	g_strlen(self->wm->client_info->program);	
	return 0;
}



int set_connect_info_vnc(struct xrdp_mm * self, const connInfo_t * conn)
{
	if(self == NULL||conn==NULL)
		return -1;
	//模块动态库libvnc.so
	list_add_item(self->login_names, (long)g_strdup("lib"));
	list_add_item(self->login_values, (long)g_strdup("libvnc.so"));
	//用户名字
	list_add_item(self->login_names, (long)g_strdup("username"));
	list_add_item(self->login_values, (long)g_strdup(conn->username));

	//密码	
	list_add_item(self->login_names, (long)g_strdup("password"));
	list_add_item(self->login_values, (long)g_strdup(conn->password));

	//ip
	list_add_item(self->login_names, (long)g_strdup("ip"));
	list_add_item(self->login_values, (long)g_strdup(conn->hostname));

	//端口
	list_add_item(self->login_names, (long)g_strdup("port"));
	list_add_item(self->login_values, (long)g_strdup(conn->port));

	return 0;
	//其他设置			
}


/*
 *add:yuliang
 *time:20190617
 */

static int writeSessionIdToFile(const char *s_name,int width,int height,const char *filename)
{
	if(s_name == NULL || filename==NULL)
		return (-1);
	FILE* fp = fopen(filename,"w");
	if(fp == NULL)
		return (-1);
	fwrite(s_name,strlen(s_name),1,fp);
	fwrite("\n",1,1,fp);

	char buffer[512]={0};
	int nlen=snprintf(buffer,512,"%d\n",width);
	fwrite(buffer,nlen,1,fp);
	nlen=snprintf(buffer,512,"%d\n",height);
	fwrite(buffer,nlen,1,fp);
	
	fclose(fp);
	return 0;
}

static int writeUserArgsToFile(struct xrdp_client_info *info,const char *filename){
	if(filename == NULL || info == NULL)
		return (-1);
	FILE* fp = fopen(filename,"w+");
	if(fp == NULL){
		perror("fopen");
		return (-1);
	}

	//文件权限必须是666，因为用户池给的用户权限是普通用户
	if(chmod(filename,0666) < 0){
		perror("chmod");
		return (-1);
	}

	int width = info->width;
	int height = info->height;
//	log_message(LOG_LEVEL_DEBUG,"width:%d",width);
//	log_message(LOG_LEVEL_DEBUG,"height:%d",height);
	char buffer[512]={0};
	int nlen=snprintf(buffer,512,"%d\n",width);
	fwrite(buffer,nlen,1,fp);
	nlen=snprintf(buffer,512,"%d\n",height);
	fwrite(buffer,nlen,1,fp);

	
	fclose(fp);
	return 0;
}


static pthread_mutex_t mutex_direct_menu = PTHREAD_MUTEX_INITIALIZER; 

static pthread_mutex_t mutex_x11_connn = PTHREAD_MUTEX_INITIALIZER;

int direct_connect_menu(struct xrdp_wm *self){
	if(self==NULL||self->config_extra->directMenuPathName==NULL){
		log_message(LOG_LEVEL_ERROR,"direct_connect_menu:argments error");
		return 1;
	}
	//配置x11信息
	if(set_connect_xorg(self) != 0){
		log_message(LOG_LEVEL_ERROR,"set_connect_xorg failed");
		return 1;
	}
	
	//写文件信息
	const char *filename = self->config_extra->directMenuPathName;
	pthread_mutex_lock(&mutex_direct_menu);
	if(writeUserArgsToFile(self->session->client_info,filename) < 0){
		log_message(LOG_LEVEL_ERROR,"writeUserArgsToFile failed");
		pthread_mutex_unlock(&mutex_direct_menu);	
		return 1;
	}
	
	int ret = 1;
	long lastModTime = extra_getLastModTime(filename);
	//连接xorg环境
	if (xrdp_mm_connect(self->mm) == 0){
		char tempsid[256] = {0};
		extra_isFileChanged(filename,lastModTime,5);
		if(extra_getDirectMenuTempSidFromFile(tempsid,256,filename)==0){
				snprintf(self->tempsid,sizeof(self->tempsid),"%s",tempsid);
				xrdp_wm_set_login_mode(self, 22);
				self->direct_menu_mode = 1;//直连菜单模式
				xrdp_wm_delete_all_children(self);
				self->dragging = 0;
				self->pid_dm = extra_getDirectMenuPidFromFile(filename);
				ret = 0;
		}else{
			log_message(LOG_LEVEL_ERROR,"extra_getDirectMenuTempSidFromFile failed");
			ret = 1;
		}
	}
	pthread_mutex_unlock(&mutex_direct_menu);
	return ret;
}

 

int xrdp_do_connect(struct xrdp_wm *self,connInfo_t *conn)
{
	if(self == NULL || conn == NULL)
		return 1;
	long lastModTime = 0L;
	const char *x11_ssid_filename = X11_SSID_FILENAME;
	if(self->config_extra->x11PathName)
		x11_ssid_filename = self->config_extra->x11PathName ;

	if(strcmp(conn->protocol,"rdp") == 0){
		if(set_connect_info_rdp(self->mm, conn) < 0){
			log_message(LOG_LEVEL_ERROR,"set_connect_info_rdp failed");
			return 1;
		}
	}
	else if(strcmp(conn->protocol,"vnc") == 0){
		if(set_connect_info_vnc(self->mm, conn) < 0){
			log_message(LOG_LEVEL_ERROR,"set_connect_info_vnc failed");
			return 1;
		}	
	}
	else if(strcmp(conn->protocol,"x11") == 0){	
		if(set_connect_info_x11(self->mm, conn) < 0){
			log_message(LOG_LEVEL_ERROR,"set_connect_info_x11 failed");
			return 1;
		}
		//加锁
		pthread_mutex_lock(&mutex_x11_connn);
		char *ssid = self->session->client_info->username;
		int width = self->session->client_info->width;
		int height = self->session->client_info->height;
		writeSessionIdToFile(ssid,width,height,x11_ssid_filename);
		if(chmod(x11_ssid_filename,0666) < 0){
			log_message(LOG_LEVEL_ERROR,"chmod() error");
			pthread_mutex_lock(&mutex_x11_connn);
			return 1;
		}
		lastModTime = extra_getLastModTime(x11_ssid_filename);
	}
	
	self->pro_layer->server_trans->tls->conn_status = 1;
	int ret = 1;
	if (xrdp_mm_connect(self->mm) == 0){		
		xrdp_wm_set_login_mode(self, 4); /* put the wm in connected mode */
		xrdp_wm_delete_all_children(self);
		self->dragging = 0;
		ret = 0;
	}
	
//extra code
	if(strcmp(conn->protocol,"x11") == 0){
		if(ret == 0){
			extra_isFileChanged(x11_ssid_filename,lastModTime,5);
			self->pid_x11_1 = extra_getPidFromFile(x11_ssid_filename,4);
			self->pid_x11_2 = extra_getPidFromFile(x11_ssid_filename,5);
		}
		pthread_mutex_unlock(&mutex_x11_connn);
	}	
//end
	return ret;
}


int loop_wait_monitor_client(struct ssl_tls *self,const char *sid)
{
	int timeout = 0;
	int max_timeout = 10;
	while(timeout++ < max_timeout){
		if(monitor_get_tls_from_array(CLIENT_MONITOR,sid) != NULL){ 
			break;
		}
		log_message(LOG_LEVEL_DEBUG,"Waiting monitor-client join:%d s",timeout);
		//sleep(1);
		extra_thread_sleep(1000000L);
	}
	return (timeout>=max_timeout?timeout:0);
}


void save_sid_to_tls(struct ssl_tls *self,const char *sid,int type)
{
	if(self == NULL)
		return;	
	mutex_lock(monitor_mutex);
	memset(self->sid,0,sizeof(self->sid));
	memcpy(self->sid,sid,strlen(sid));
	self->type = type;
	mutex_unlock(monitor_mutex);
}

void copy_client_info(struct xrdp_client_info*dst,struct xrdp_client_info*src)
{
	dst->rdp5_performanceflags = src->rdp5_performanceflags;
	dst->rdp_compression = src->rdp_compression;
	//	dst->rdp_autologin = src->rdp_autologin;
	//	dst->no_orders_supported = src->no_orders_supported;
	//	dst->use_compact_packets = src->use_compact_packets;
	//	dst->use_fast_path = src->use_fast_path;
	//	dst->use_cache_glyph_v2 = src->use_cache_glyph_v2;
	//	dst->offscreen_support_level = src->offscreen_support_level;
	//	dst->offscreen_cache_size=src->offscreen_cache_size;
	//	dst->offscreen_cache_entries=src->offscreen_cache_entries;
	//	dst->brush_cache_code = src->brush_cache_code;
	//	dst->client_os_minor=src->client_os_minor;
	//	dst->client_os_major=src->client_os_major;
	//	dst->max_unacknowledged_frame_count = src->max_unacknowledged_frame_count;
	//	dst->use_frame_acks=src->use_frame_acks;
	//	dst->mcs_early_capability_flags=src->mcs_early_capability_flags;
	//	dst->mcs_connection_type=src->mcs_connection_type;
	//	dst->keyboard_type = src->keyboard_type;
	//	dst->order_flags_ex=src->order_flags_ex;
	//	dst->ns_prop_len=src->ns_prop_len;
	//	dst->ns_codec_id=src->ns_codec_id;
	//	dst->rfx_prop_len=src->rfx_prop_len;
	//	dst->rfx_codec_id = src->rfx_codec_id;	
	//	dst->build=src->build;
	//	dst->bitmap_cache_version=src->bitmap_cache_version;
	//	dst->bitmap_cache_persist_enable=src->bitmap_cache_persist_enable;
	//	dst->pointer_cache_entries=src->pointer_cache_entries;
	//	dst->cache3_entries=src->cache3_entries;
	//	dst->cache2_entries=src->cache2_entries;
}

/*
 *@auth:yuliang
 *@time:20190726
 *@fun:设置主会话与监控会话的连接逻辑，
 *主会话需要请求redis获取目标机参数
 *主会话与监控会话的ssl流信息需要存入数组中
 */

int setup_connection(struct xrdp_wm *self)
{
	if(self == NULL || self->session==NULL || \
		self->session->client_info==NULL)
		return 1;
	
	const char *sid = self->session->client_info->username;
	if(strlen(self->ssid) > 0)
		sid = self->ssid;
	log_message(LOG_LEVEL_DEBUG,"ssid:%s\n",sid);

	struct trans *ptrans = self->pro_layer->server_trans;
	ptrans->tls->wm = self;
	connInfo_t *conn = self->connect_info;
	PullDataInfo_t tmpDataValue={NULL,NULL};
	tmpDataValue.conn = conn;
	tmpDataValue.pCliInfo = self->session->client_info;
	self->myType = monitor_get_client_type(sid);
	if(self->myType == CLIENT_MAIN){
		save_sid_to_tls(ptrans->tls,sid,self->myType);
		if(monitor_add_client_tls(self->myType,sid,ptrans->tls) < 0){
			log_message(LOG_LEVEL_ERROR,"monitor_add_client failed:%s",sid);
			return 1;
		}		
#if 1
		setup_conn_info(conn, sid);	
		conn->mstscflag = false;
#else
		if(query_conn_server(&tmpDataValue,self->config_extra->localIp) < 0 ){
			log_message(LOG_LEVEL_ERROR,"query_conn_server failed:%s",sid);
			return 1;
		}
#endif
		show_conn_info(conn);

		//如果mstscflag等于true，表示需要阻塞等待监控会话过来
		if(conn->mstscflag == true){
			ptrans->tls->mstscflag = true;
			//等待监控客户端进入
			if(loop_wait_monitor_client(ptrans->tls,sid) != 0){
				log_message(LOG_LEVEL_ERROR,"loop_wait_monitor_client:timeout");
				return 1;
			}
			//使用监控会话的配置设置主会话的配置
			struct ssl_tls *tls = monitor_get_tls_from_array(CLIENT_MONITOR,sid);
			if(tls != NULL)
				copy_client_info(self->client_info,tls->wm->client_info);
		}
		return xrdp_do_connect(self,self->connect_info);
	}
	else if(self->myType == CLIENT_MONITOR){
		save_sid_to_tls(ptrans->tls,sid,self->myType);
		xrdp_wm_set_login_mode(self, 3);
		xrdp_wm_delete_all_children(self);
		self->dragging = 0;
		if(monitor_add_client_tls(self->myType,sid,ptrans->tls) < 0){
			log_message(LOG_LEVEL_ERROR,"monitor_add_client failed:%s\n",sid);
			return 1;
		}
	}
	else if(self->myType == CLIENT_OTHER){
		log_message(LOG_LEVEL_ERROR,"invalid client:CLIENT_OTHER\n");
		return 1;
	}
	return 0;
}


/******************************************************************************/
/* returns error */
/* this gets called when there is nothing on any socket */
static int
xrdp_wm_login_mode_changed(struct xrdp_wm *self)
{
	if (self == 0){
		return 0;
	}
	g_writeln("xrdp_wm_login_mode_changed: login_mode is %d", self->login_mode);
	if (self->login_mode == 0){
		xrdp_wm_set_login_mode(self, 1);
		list_clear(self->log);
		xrdp_wm_delete_all_children(self);
		self->dragging = 0;
		xrdp_wm_init(self);
	}
	else if(self->login_mode == 21){
		//直连菜单逻辑
		return direct_connect_menu(self);	
	}
	else if (self->login_mode == 2){
		//协议代理逻辑
		return setup_connection(self);
	}
	else if (self->login_mode == 10){
		xrdp_wm_delete_all_children(self);
		self->dragging = 0;
		xrdp_wm_set_login_mode(self, 11);
	}
	else if(self->login_mode == 20){
		//断开连接，有监控会话线程或主会话互相发起
		return 1;
	}
	return 0;
}




/*****************************************************************************/
/* this is the log windows notify function */
	static int
xrdp_wm_log_wnd_notify(struct xrdp_bitmap *wnd,
		struct xrdp_bitmap *sender,
		int msg, long param1, long param2)
{
	struct xrdp_painter *painter;
	struct xrdp_wm *wm;
	struct xrdp_rect rect;
	int index;
	char *text;

	if (wnd == 0)
	{
		return 0;
	}

	if (sender == 0)
	{
		return 0;
	}

	if (wnd->owner == 0)
	{
		return 0;
	}

	wm = wnd->wm;

	if (msg == 1) /* click */
	{
		if (sender->id == 1) /* ok button */
		{
			/* close the log window */
			MAKERECT(rect, wnd->left, wnd->top, wnd->width, wnd->height);
			xrdp_bitmap_delete(wnd);
			xrdp_bitmap_invalidate(wm->screen, &rect);

			/* if module is gone, reset the session when ok is clicked */
			if (wm->mm->mod_handle == 0)
			{
				/* make sure autologin is off */
				wm->session->client_info->rdp_autologin = 0;
				xrdp_wm_set_login_mode(wm, 0); /* reset session */
			}
		}
	}
	else if (msg == WM_PAINT) /* 3 */
	{
		painter = (struct xrdp_painter *)param1;

		if (painter != 0)
		{
			painter->fg_color = wnd->wm->black;

			for (index = 0; index < wnd->wm->log->count; index++)
			{
				text = (char *)list_get_item(wnd->wm->log, index);
				xrdp_painter_draw_text(painter, wnd, 10, 30 + index * 15, text);
			}
		}
	}

	return 0;
}

	static void
add_string_to_logwindow(const char *msg, struct list *log)
{
	const char *new_part_message;
	const char *current_pointer = msg;
	int len_done = 0;

	do
	{
		new_part_message = g_strndup(current_pointer, LOG_WINDOW_CHAR_PER_LINE);
		g_writeln("%s", new_part_message);
		list_add_item(log, (tintptr) new_part_message);
		len_done += g_strlen(new_part_message);
		current_pointer += g_strlen(new_part_message);
	} while ((len_done < g_strlen(msg)) && (len_done < DEFAULT_STRING_LEN));
}

/*****************************************************************************/
	int
xrdp_wm_show_log(struct xrdp_wm *self)
{
	struct xrdp_bitmap *but;
	int w;
	int h;
	int xoffset;
	int yoffset;
	int index;
	int primary_x_offset;
	int primary_y_offset;


	if (self->hide_log_window)
	{
		/* make sure autologin is off */
		self->session->client_info->rdp_autologin = 0;
		xrdp_wm_set_login_mode(self, 0); /* reset session */
		return 0;
	}

	if (self->log_wnd == 0)
	{
		w = DEFAULT_WND_LOG_W;
		h = DEFAULT_WND_LOG_H;
		xoffset = 10;
		yoffset = 10;

		if (self->screen->width < w)
		{
			w = self->screen->width - 4;
			xoffset = 2;
		}

		if (self->screen->height < h)
		{
			h = self->screen->height - 4;
			yoffset = 2;
		}

		primary_x_offset = 0;
		primary_y_offset = 0;

		/* multimon scenario, draw log window on primary monitor */
		if (self->client_info->monitorCount > 1)
		{
			for (index = 0; index < self->client_info->monitorCount; index++)
			{
				if (self->client_info->minfo_wm[index].is_primary)
				{
					primary_x_offset = self->client_info->minfo_wm[index].left;
					primary_y_offset = self->client_info->minfo_wm[index].top;
					break;
				}
			}
		}

		/* log window */
		self->log_wnd = xrdp_bitmap_create(w, h, self->screen->bpp,
				WND_TYPE_WND, self);
		list_add_item(self->screen->child_list, (long)self->log_wnd);
		self->log_wnd->parent = self->screen;
		self->log_wnd->owner = self->screen;
		self->log_wnd->bg_color = self->grey;
		self->log_wnd->left = primary_x_offset + xoffset;
		self->log_wnd->top = primary_y_offset + yoffset;
		set_string(&(self->log_wnd->caption1), "Connection Log");
		/* ok button */
		but = xrdp_bitmap_create(DEFAULT_BUTTON_W, DEFAULT_BUTTON_H, self->screen->bpp, WND_TYPE_BUTTON, self);
		list_insert_item(self->log_wnd->child_list, 0, (long)but);
		but->parent = self->log_wnd;
		but->owner = self->log_wnd;
		but->left = (w - DEFAULT_BUTTON_W) - xoffset;
		but->top = (h - DEFAULT_BUTTON_H) - yoffset;
		but->id = 1;
		but->tab_stop = 1;
		set_string(&but->caption1, "OK");
		self->log_wnd->focused_control = but;
		/* set notify function */
		self->log_wnd->notify = xrdp_wm_log_wnd_notify;
	}

	xrdp_wm_set_focused(self, self->log_wnd);
	xrdp_bitmap_invalidate(self->log_wnd, 0);

	return 0;
}

/*****************************************************************************/
	int
xrdp_wm_log_msg(struct xrdp_wm *self, enum logLevels loglevel,
		const char *fmt, ...)
{
	va_list ap;
	char msg[256];

	va_start(ap, fmt);
	vsnprintf(msg, sizeof(msg), fmt, ap);
	va_end(ap);

	log_message(loglevel, "xrdp_wm_log_msg: %s", msg);
	add_string_to_logwindow(msg, self->log);
	return 0;
}

/*****************************************************************************/
	int
xrdp_wm_get_wait_objs(struct xrdp_wm *self, tbus *robjs, int *rc,
		tbus *wobjs, int *wc, int *timeout)
{
	int i;

	if (self == 0)
	{
		return 0;
	}

	i = *rc;
	robjs[i++] = self->login_mode_event;
	*rc = i;
	return xrdp_mm_get_wait_objs(self->mm, robjs, rc, wobjs, wc, timeout);
}


/******************************************************************************/
int
xrdp_wm_check_wait_objs(struct xrdp_wm *self)
{
	int rv;

	if (self == 0){
		return 0;
	}

	rv = 0;

	if (g_is_wait_obj_set(self->login_mode_event))
	{
		g_reset_wait_obj(self->login_mode_event);
		if(xrdp_wm_login_mode_changed(self) != 0){
			return 1;
		}
	}

	if (rv == 0){
		rv = xrdp_mm_check_wait_objs(self->mm);
	}

	return rv;
}

/*****************************************************************************/
int xrdp_wm_set_login_mode(struct xrdp_wm *self, int login_mode)
{
	self->login_mode = login_mode;
	g_set_wait_obj(self->login_mode_event);
	return 0;
}


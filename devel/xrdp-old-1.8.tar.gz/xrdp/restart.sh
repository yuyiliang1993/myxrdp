make
make install
xrdp -ns

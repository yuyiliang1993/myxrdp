
This is a fast jpeg2000 codec compatible with MS RDP servers and xrdp.

Assembly code in critial parts to maximize speed.

Use this to push
git remote set-url origin git@github.com:neutrinolabs/librfxcodec.git

